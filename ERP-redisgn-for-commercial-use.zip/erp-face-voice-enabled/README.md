# 🧑‍💼 Employee Face Recognition Attendance System

A Django-based employee attendance system powered by **face recognition** and **voice confirmation**. Designed for ease of use, automation, and advanced reporting, this system streamlines employee attendance tracking with a modern touch.

---

## 🚀 Features

- **🔍 Face Recognition Attendance**  
  Mark attendance automatically using webcam-based face recognition.

- **🎙️ Hands-Free Voice Confirmation**  
  System asks: _"Do you want to mark your attendance? Say yes or no."_  
  Marks attendance based on your spoken response.

- **⏰ Automated Attendance Updates**
  - **Lunch Out**: Automatically set `LUNCH_OUT` if `LUNCH_IN` and time > 2:30 PM.
  - **Daily Checkout**: Automatically set `OUT` if no checkout by 11:00 PM.

- **👨‍💼 Employee Management**  
  Add new employees with personal details and a photo for face recognition.

- **📊 Attendance Report & Filtering**
  - Filter by **date range**, **employee**, **attendance type**, and **working hours**.

- **📱 Responsive Design**  
  Works across desktops, tablets, and mobile devices.

---

## 🛠️ Setup and Installation (Windows)

### 🔗 Prerequisites

- **Python 3.x**  
  [Download Python](https://www.python.org/downloads/) and add it to your PATH.

- **FFmpeg**  
  Required for audio processing.  
  [Download FFmpeg](https://ffmpeg.org/download.html)  
  [How to Install FFmpeg on Windows](https://www.geeksforgeeks.org/how-to-install-ffmpeg-on-windows/)

- **dlib Precompiled Wheel**  
  Save `dlib-19.24.99-cp313-cp313-win_amd64.whl` inside `./wheels/` in your root directory.

---

### ⚙️ Installation Steps

```bash
git clone <your-repository-url>
cd <your-project-directory>
run_server.bat
```

This script will:

- Set up a Python virtual environment
- Install the dlib wheel and other dependencies
- Check for FFmpeg
- Apply migrations
- Launch the Django development server

---

## 🧪 Usage Instructions

### 🔹 1. Open the Web Interface  
Visit: [http://127.0.0.1:8000/](http://127.0.0.1:8000/)

### 🔹 2. Register Employees  
Navigate to **Register Employee**, fill the form, and upload a clear face photo.

### 🔹 3. Mark Attendance  
- Go to **Mark Attendance**  
- Stand in front of webcam  
- System asks: _"Do you want to mark your attendance?"_  
- Say **"yes"** or **"no"**

### 🔹 4. View Attendance Reports  
Go to **View Attendance Report**  
Apply filters:
- 📅 Date Range
- 🧑 Specific Employees
- 📍 Attendance Types
- ⏱️ Worked Hours Less Than X

---

## 🗂️ Project Structure (Simplified)

```
your-project/
│
├── manage.py
├── requirements.txt
├── run_server.bat
├── wheels/
│   └── dlib-19.24.99-cp313-cp313-win_amd64.whl
│
├── attendance_app/
│   ├── models.py
│   ├── views.py
│   ├── urls.py
│   ├── forms.py
│   └── face_recognizer.py
│
├── templates/
│   └── attendance_app/
│       ├── mark_attendance.html
│       ├── register_employee.html
│       ├── attendance_report.html
│       └── employee_list.html
```

---

## 🧯 Troubleshooting

| Issue | Solution |
|-------|----------|
| **Python not found** | Ensure Python is installed and added to PATH |
| **FFmpeg errors** | Verify installation and `ffmpeg/bin` is in PATH |
| **dlib fails to install** | Ensure `.whl` file matches Python version and is in `./wheels/` |
| **Voice not detected** | Allow microphone permissions in browser |
| **Speech not recognized** | Ensure clear audio; check internet if using online recognition |
| **Wrong attendance marking** | Debug logic in `views.py → determine_attendance_type()` |

---

## 🤝 Contributing

Feel free to:
- Fork the repo
- Submit pull requests
- Report bugs or request features

---

## 📜 License

This project is open source. Use it freely and contribute as you wish.

---