import cv2
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods, require_POST
from django.views.decorators.csrf import csrf_exempt
from django.db import transaction
from django.db import connection
from django.views.decorators.cache import never_cache
from django.conf import settings
from django.utils import timezone
from django.db.models import Max, Min, Q

import datetime
import numpy as np
from PIL import Image
from datetime import datetime, time, timedelta, date
import io
import pickle

# IMPORTS FOR SPEECH RECOGNITION AND AUDIO PROCESSING
import speech_recognition as sr
from pydub import AudioSegment # New import for pydub

from .models import AttendanceRecord
from .forms import EmployeeForm
from .models import Employee, AttendanceRecord
from .face_recognizer import FaceRecognitionSystem

_face_recognition_system_instance = None


def get_face_recognition_system():
    global _face_recognition_system_instance
    if _face_recognition_system_instance is None:
        _face_recognition_system_instance = FaceRecognitionSystem(tolerance=0.6)
    return _face_recognition_system_instance


# --- Employee Management Views ---

class AttendanceManager:
    # Time windows for different attendance types
    IN_TIME_START = time(10, 0)  # 10:00 AM
    IN_TIME_END = time(11, 0)  # 11:00 AM
    LUNCH_TIME_START = time(13, 30)  # 1:30 PM
    LUNCH_TIME_END = time(14, 30)  # 2:30
    MAX_LUNCH_DURATION = timedelta(hours=1, minutes=30)  # Increased tolerance for lunch
    OUT_TIME_MIN = time(19, 0)  # 7:00 PM
    OFFICE_CLOSE = time(23, 0)  # 11:00 PM for auto-checkout

    @staticmethod
    def auto_checkout_employees():
        today = date.today()
        # Find employees who checked in but haven't checked out for today
        employees_in_today = Employee.objects.filter(
            attendance_records__date=today,
            attendance_records__attendance_type='IN'
        ).distinct()

        for employee in employees_in_today:
            # Check if there's an 'OUT' record for today
            has_checked_out = AttendanceRecord.objects.filter(
                employee=employee,
                date=today,
                attendance_type='OUT'
            ).exists()

            if not has_checked_out:
                # Mark as 'OUT' with a remark for auto-checkout
                AttendanceManager.create_attendance_record(
                    employee=employee,
                    attendance_type='OUT',
                    remarks=f"Auto-checked out at {AttendanceManager.OFFICE_CLOSE.strftime('%H:%M')} (Overtime not counted)"
                )
                print(f"Auto-checked out employee: {employee.name}")

    @staticmethod
    def determine_attendance_type(employee):
        current_time = datetime.now().time()
        today = datetime.now().date()

        today_records = AttendanceRecord.objects.filter(employee=employee, date=today).order_by('time')
        last_record = today_records.last()

        # If no records for today, it's always IN
        if not last_record:
            remark = ""
            if current_time > AttendanceManager.IN_TIME_END:
                remark = "Late entry."
            elif current_time < AttendanceManager.IN_TIME_START:
                remark = "Early entry."
            return 'IN', f"{employee.name}: In Time. {remark}"

        current_state = last_record.attendance_type

        # Define common messages for already marked status
        msg_already_in = f"{employee.name}: Already Checked In."
        msg_already_out = f"{employee.name}: Already Checked Out."
        msg_already_on_lunch = f"{employee.name}: Already on Lunch. Expected Lunch Out."
        msg_already_on_break = f"{employee.name}: Already on a Break. Expected Break Out."
        msg_returning_from_lunch = f"{employee.name}: Returning from Lunch. Still active."
        msg_returning_from_break = f"{employee.name}: Returning from Break. Still active."

        if current_state == 'IN':
            # Check for LUNCH_IN
            # A new LUNCH_IN is valid only if the last specific lunch record was LUNCH_OUT or there are no lunch records
            last_lunch_record = today_records.filter(
                Q(attendance_type='LUNCH_IN') | Q(attendance_type='LUNCH_OUT')).last()
            if current_time >= AttendanceManager.LUNCH_TIME_START and current_time <= AttendanceManager.LUNCH_TIME_END:
                if not last_lunch_record or last_lunch_record.attendance_type == 'LUNCH_OUT':
                    return 'LUNCH_IN', f"{employee.name}: Lunch In"
                else:  # last_lunch_record was LUNCH_IN
                    return None, msg_already_on_lunch

            # Check for BREAK IN
            # A new BREAK IN is valid only if the last specific break record was BREAK OUT or there are no break records
            last_break_record = today_records.filter(
                Q(attendance_type='BREAK IN') | Q(attendance_type='BREAK OUT')).last()
            if not last_break_record or last_break_record.attendance_type == 'BREAK OUT':
                return 'BREAK IN', f"{employee.name}: Break In"
            else:  # last_break_record was BREAK IN
                return None, msg_already_on_break

            # # Check for OUT
            # # Ensure they haven't already explicitly OUT'ed for the day
            # if current_time > AttendanceManager.OUT_TIME_MIN:
            #     if not today_records.filter(attendance_type='OUT').exists():
            #         return 'OUT', f"{employee.name}: Out Time"
            #     else:
            #         return None, msg_already_out
            #
            # # If still 'IN' and not going for lunch/break/out, then no change needed (already IN)
            # return None, msg_already_in

        elif current_state == 'LUNCH_IN':
            # === MODIFICATION START ===
            # If current time is past LUNCH_TIME_END (2:30 PM) and they are still LUNCH_IN, auto-mark LUNCH_OUT
            if current_time > AttendanceManager.LUNCH_TIME_END:
                return 'LUNCH_OUT', f"{employee.name}: Auto Lunch Out (past {AttendanceManager.LUNCH_TIME_END.strftime('%H:%M')})."
            # === MODIFICATION END ===

            # Otherwise, after LUNCH_IN, the only valid immediate next state is LUNCH_OUT (if not past auto-out time)
            return 'LUNCH_OUT', f"{employee.name}: Lunch Out"

        elif current_state == 'LUNCH_OUT':
            # After LUNCH_OUT, they are effectively back 'IN' for work, or could be OUT
            if current_time > AttendanceManager.OUT_TIME_MIN:
                if not today_records.filter(attendance_type='OUT').exists():
                    return 'OUT', f"{employee.name}: Out Time"
                else:
                    return None, msg_already_out
            else:
                # If not yet OUT, they are considered back at work (IN).
                # No new 'IN' record is created for simply returning from lunch if the main 'IN' hasn't been 'OUT'ed yet.
                return None, msg_returning_from_lunch

        elif current_state == 'BREAK IN':
            # After BREAK IN, the only valid immediate next state is BREAK OUT
            return 'BREAK OUT', f"{employee.name}: Break Out"

        elif current_state == 'BREAK OUT':
            # After BREAK OUT, they are effectively back 'IN' for work, or could be OUT
            if current_time > AttendanceManager.OUT_TIME_MIN:
                if not today_records.filter(attendance_type='OUT').exists():
                    return 'OUT', f"{employee.name}: Out Time"
                else:
                    return None, msg_already_out
            else:
                # If not yet OUT, they are considered back at work (IN).
                # Similar to LUNCH_OUT, no new 'IN' record for simply returning from break.
                return None, msg_returning_from_break

        elif current_state == 'OUT':
            # If already OUT for the day, a new scan means a new 'IN' session (e.g., overtime, second shift)
            # This is a valid transition that allows for new records after a final OUT.
            return 'IN', f"{employee.name}: Starting new session (After daily OUT)."

        # Default case: if no valid transition is found, or an illogical scan occurs
        return None, "No specific attendance action needed based on current state and time."


    @staticmethod
    def create_attendance_record(employee, attendance_type, remarks=""):
        """Creates a new attendance record for the employee."""
        # Ensure we use timezone.now() for timezone-aware datetimes
        AttendanceRecord.objects.create(
            employee=employee,
            date=date.today(),
            time=datetime.now().time(),  # time() doesn't include timezone, which is fine for TimeField
            attendance_type=attendance_type,
            remarks=remarks
        )
        employee.last_seen = timezone.now()
        employee.save()
        print(f"Attendance recorded for {employee.name} as {attendance_type}")

    @staticmethod
    def calculate_working_hours(employee, target_date):
        records = AttendanceRecord.objects.filter(employee=employee, date=target_date).order_by('time')

        total_working_seconds = 0
        lunch_duration_seconds = 0
        break_duration_seconds = 0

        last_in_time = None
        lunch_in_time = None
        break_in_time = None

        in_out_pairs = []

        for record in records:
            if record.attendance_type == 'IN':
                last_in_time = record.time
            elif record.attendance_type == 'OUT' and last_in_time:
                duration = datetime.combine(target_date, record.time) - datetime.combine(target_date, last_in_time)
                total_working_seconds += duration.total_seconds()
                in_out_pairs.append((last_in_time, record.time))
                last_in_time = None
            elif record.attendance_type == 'LUNCH_IN':
                lunch_in_time = record.time
            elif record.attendance_type == 'LUNCH_OUT' and lunch_in_time:
                duration = datetime.combine(target_date, record.time) - datetime.combine(target_date, lunch_in_time)
                lunch_duration_seconds += duration.total_seconds()
                lunch_in_time = None
            elif record.attendance_type == 'BREAK IN':
                break_in_time = record.time
            elif record.attendance_type == 'BREAK OUT' and break_in_time:
                duration = datetime.combine(target_date, record.time) - datetime.combine(target_date, break_in_time)
                break_duration_seconds += duration.total_seconds()
                break_in_time = None

        has_out = False
        if last_in_time and not AttendanceRecord.objects.filter(employee=employee, date=target_date,
                                                                attendance_type='OUT').exists():
            current_datetime = datetime.now()
            if target_date == current_datetime.date():
                duration = current_datetime - datetime.combine(target_date, last_in_time)
                total_working_seconds += duration.total_seconds()

        else:
            has_out = True

        total_working_hours = round(total_working_seconds / 3600, 2)
        lunch_duration_hours = round(lunch_duration_seconds / 3600, 2)
        break_duration_hours = round(break_duration_seconds / 3600, 2)

        return total_working_hours, lunch_duration_hours, break_duration_hours, has_out


@require_http_methods(["GET", "POST"])
@transaction.atomic
def register_employee(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            employee = form.save(commit=False)
            employee.save()

            face_recognition_system = get_face_recognition_system()

            if face_recognition_system.register_employee(employee.employee_id):
                return redirect('attendance_app:employee_list')
            else:
                form.add_error(None,
                               "Face registration failed. Please try again with a clear photo or ensure webcam is accessible.")

    else:
        form = EmployeeForm()

    return render(request, 'attendance_app/register_employee.html', {'form': form})


def employee_list(request):
    employees = Employee.objects.all().order_by('name')
    context = {
        'employees': employees
    }
    return render(request, 'attendance_app/employee_list.html', context)


def mark_attendance(request):
    return render(request, 'attendance_app/mark_attendance.html')


@csrf_exempt
@require_http_methods(["POST"])
@transaction.atomic
def mark_attendance_capture(request):
    try:
        uploaded_file = request.FILES.get('attendance_photo')

        if not uploaded_file:
            return JsonResponse({"status": "error", "message": "No image file provided."}, status=400)

        img_bytes = uploaded_file.read()
        nparr = np.frombuffer(img_bytes, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if frame is None:
            return JsonResponse({"status": "error", "message": "Could not decode image from file."}, status=400)

        face_recognition_system = get_face_recognition_system()
        recognized_names = face_recognition_system.recognize_face(frame)

        if recognized_names:
            recognized_name = recognized_names[0]
            if recognized_name != "Unknown":
                employee = get_object_or_404(Employee, name=recognized_name)

                # Determine attendance type and message
                attendance_type, message = AttendanceManager.determine_attendance_type(employee)

                if attendance_type:  # Only create record if a valid attendance_type is returned
                    AttendanceManager.create_attendance_record(employee, attendance_type)
                    return JsonResponse({
                        "status": "success",
                        "recognized": [recognized_name],
                        "marked": [{"type": attendance_type, "message": message}],
                        "messages": [f"Attendance marked for {employee.name}: {attendance_type}. {message}"]
                    })
                else:
                    # No new record created because no state change, but recognition was successful.
                    return JsonResponse({
                        "status": "warning",
                        "message": message,  # Message from determine_attendance_type (e.g., "Already on a Break.")
                        "recognized": [recognized_name],
                        "marked": [],
                        "messages": [message]
                    })
            else:
                return JsonResponse({"status": "warning", "message": "No recognizable face detected."}, status=200)
        else:
            return JsonResponse({"status": "warning", "message": "No face detected in the image."}, status=200)

    except Exception as e:
        print(f"Error in mark_attendance_capture: {e}")
        return JsonResponse(
            {"status": "error", "message": f"An error occurred: {str(e)}", "recognized": [], "marked": [],
             "messages": [f"Backend error: {str(e)}"]}, status=500)

@require_http_methods(["GET"])
def recent_attendance_records(request):
    try:
        # Get employees who have had any attendance recorded in the last few days
        # Adjust 'days=7' as per how "recent" you want the records to be
        cutoff_date = timezone.localdate() - timedelta(days=7) # Records from last 7 days

        # Get distinct employees who have records within the cutoff period, ordered by last activity
        recent_employee_ids = AttendanceRecord.objects.filter(
            date__gte=cutoff_date
        ).order_by('-date', '-time').values_list('employee_id', flat=True).distinct()[:10] # Limit to top 10 distinct employees

        data = []
        for emp_id in recent_employee_ids:
            try:
                employee = Employee.objects.get(employee_id=emp_id)

                # Get the most recent date for which this employee has records
                latest_date_for_employee = AttendanceRecord.objects.filter(
                    employee=employee
                ).aggregate(max_date=Max('date'))['max_date']

                if not latest_date_for_employee:
                    continue # Skip if no records for this employee

                # Fetch all records for this employee for their latest active date
                daily_records = AttendanceRecord.objects.filter(
                    employee=employee,
                    date=latest_date_for_employee
                ).order_by('time')

                # Aggregate times for the specific day
                in_time = None
                out_time = None
                lunch_in_time = None
                lunch_out_time = None
                break_in_time = None
                break_out_time = None
                remarks_list = [] # Collect all remarks for the day

                for record in daily_records:
                    if record.attendance_type == 'IN' and not in_time: # Only capture the first IN
                        in_time = record.time
                    elif record.attendance_type == 'OUT': # Capture the last OUT
                        out_time = record.time
                    elif record.attendance_type == 'LUNCH_IN':
                        lunch_in_time = record.time
                    elif record.attendance_type == 'LUNCH_OUT':
                        lunch_out_time = record.time
                    elif record.attendance_type == 'BREAK IN':
                        break_in_time = record.time
                    elif record.attendance_type == 'BREAK OUT':
                        break_out_time = record.time
                    if record.remarks:
                        remarks_list.append(record.remarks)

                # Combine remarks
                combined_remarks = "; ".join(remarks_list) if remarks_list else None

                data.append({
                    'employee_name': employee.name,
                    'employee_id': employee.employee_id,
                    'photo_url': employee.photo.url if employee.photo else static('img/default_avatar.png'), # Assuming you have a default avatar
                    'date': latest_date_for_employee.strftime('%Y-%m-%d'),
                    'in_time': in_time.strftime('%I:%M %p') if in_time else None,
                    'out_time': out_time.strftime('%I:%M %p') if out_time else None,
                    'lunch_in_time': lunch_in_time.strftime('%I:%M %p') if lunch_in_time else None,
                    'lunch_out_time': lunch_out_time.strftime('%I:%M %p') if lunch_out_time else None,
                    'break_in_time': break_in_time.strftime('%I:%M %p') if break_in_time else None,
                    'break_out_time': break_out_time.strftime('%I:%M %p') if break_out_time else None,
                    'remarks': combined_remarks,
                })

            except Employee.DoesNotExist:
                # Handle cases where an employee_id from records_queryset doesn't exist anymore
                print(f"Employee with ID {emp_id} not found, skipping.")
                continue

        return JsonResponse(data, safe=False)
    except Exception as e:
        print(f"Error fetching recent attendance records: {e}")
        return JsonResponse({'error': 'Failed to fetch recent records'}, status=500)

def attendance_report(request):
    employees = Employee.objects.all().order_by('name')
    attendance_summary = []

    date_filter = request.GET.get('date')
    employee_filters = request.GET.getlist('employee_id')

    if date_filter:
        try:
            filter_date_obj = datetime.strptime(date_filter, '%Y-%m-%d').date()
        except ValueError:
            filter_date_obj = None
    else:
        filter_date_obj = date.today()

    records_queryset = AttendanceRecord.objects.all()

    if filter_date_obj:
        records_queryset = records_queryset.filter(date=filter_date_obj)

    if employee_filters:
        records_queryset = records_queryset.filter(employee__employee_id__in=employee_filters)

    if filter_date_obj or employee_filters:
        target_employees = Employee.objects.filter(
            id__in=records_queryset.values('employee__id')
        ).distinct().order_by('name')
    else:
        target_employees = Employee.objects.all().order_by('name')

    for employee in target_employees:
        total_hours, lunch_time, break_time, has_out = AttendanceManager.calculate_working_hours(employee,
                                                                                                 filter_date_obj or date.today())

        in_record = records_queryset.filter(employee=employee, attendance_type='IN').first()
        out_record = records_queryset.filter(employee=employee, attendance_type='OUT').first()
        lunch_in_record = records_queryset.filter(employee=employee, attendance_type='LUNCH_IN').first()
        lunch_out_record = records_queryset.filter(employee=employee, attendance_type='LUNCH_OUT').first()

        attendance_summary.append({
            'employee_name': employee.name,
            'employee_id': employee.employee_id,
            'date': filter_date_obj.strftime('%Y-%m-%d') if filter_date_obj else '',
            'in_time': in_record.time.strftime('%H:%M:%S') if in_record else None,
            'out_time': out_record.time.strftime('%H:%M:%S') if out_record else None,
            'has_out': has_out,
            'lunch_in_time': lunch_in_record.time.strftime('%H:%M:%S') if lunch_in_record else None,
            'lunch_out_time': lunch_out_record.time.strftime('%H:%M:%S') if lunch_out_record else None,
            'break_time': break_time,
            'total_working_hours': total_hours
        })

    context = {
        'attendance_records': attendance_summary,
        'employees': employees,
        'filter_date': date_filter,
        'filter_employee_id': employee_filters,
    }

    return render(request, 'attendance_app/attendance_report.html', context)


@never_cache
def health_check(request):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()

        status_info = {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "service": "Attendance System",
            "database": "connected",
            "debug_mode": settings.DEBUG
        }

        return JsonResponse(status_info)

    except Exception as e:
        error_info = {
            "status": "unhealthy",
            "timestamp": datetime.now().isoformat(),
            "error": str(e),
            "service": "Attendance System",
            "database": "disconnected"
        }
        return JsonResponse(error_info, status=500)


@require_http_methods(["GET"])
def get_current_working_hours(request, employee_id, date):
    try:
        employee = get_object_or_404(Employee, employee_id=employee_id)
        target_date = datetime.strptime(date, '%Y-%m-%d').date()

        total_hours, lunch_time, break_time, has_out = AttendanceManager.calculate_working_hours(employee, target_date)

        return JsonResponse({
            'employee_id': employee_id,
            'date': date,
            'total_working_hours': total_hours,
            'lunch_duration': lunch_time,
            'break_duration': break_time,
            'has_out': has_out
        })
    except Employee.DoesNotExist:
        return JsonResponse({"status": "error", "message": "Employee not found."}, status=404)
    except ValueError:
        return JsonResponse({"status": "error", "message": "Invalid date format."}, status=400)
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=500)


@require_http_methods(["GET"])
def check_face_position(request):
    return JsonResponse({"status": "ok", "message": "Face position check endpoint (placeholder)"})


@csrf_exempt
@require_POST
def process_speech_confirmation(request):
    """
    Receives an audio recording, converts it to WAV using pydub,
    performs speech-to-text, and determines confirmation.
    """
    if request.method == 'POST':
        audio_file = request.FILES.get('audio_recording')
        if not audio_file:
            return JsonResponse({'status': 'error', 'message': 'No audio file received.'}, status=400)

        # Create a recognizer instance
        r = sr.Recognizer()

        try:
            audio_data_raw = audio_file.read()

            # IMPORTANT CHANGE: Assume 'webm' format from the frontend.
            # pydub will use ffmpeg to handle the conversion.
            audio = AudioSegment.from_file(io.BytesIO(audio_data_raw), format="webm")

            # Export audio to a BytesIO object in WAV format,
            # which SpeechRecognition prefers for direct reading.
            wav_audio_io = io.BytesIO()
            audio.export(wav_audio_io, format="wav")
            wav_audio_io.seek(0) # Rewind to the beginning of the BytesIO object

            with sr.AudioFile(wav_audio_io) as source:
                audio_data = r.record(source)

            text = r.recognize_google(audio_data)
            print(f"Recognized speech: '{text}'") # For debugging

            confirmed = False
            message = "Voice command unrecognized or unclear."

            confirmation_words = ["yes", "yep", "sure", "haa", "ok", "okay", "okayay", "okayayay"]


            if text.lower() in confirmation_words:
                confirmed = True
                message = "Confirmation received: Yes."
            elif "no" in text.lower() or "nope" in text.lower():
                confirmed = False
                message = "Confirmation received: No."

            return JsonResponse({
                'status': 'success',
                'transcription': text,
                'confirmation': confirmed,
                'message': message
            })

        except sr.UnknownValueError:
            return JsonResponse({'status': 'warning', 'message': 'Speech recognition could not understand audio.'})
        except sr.RequestError as e:
            return JsonResponse({'status': 'error', 'message': f"Could not request results from speech recognition service; {e}"})
        except Exception as e:
            print(f"Error in process_speech_confirmation: {e}")
            return JsonResponse({'status': 'error', 'message': f"An unexpected error occurred during speech processing: {e}"})

    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=405)
