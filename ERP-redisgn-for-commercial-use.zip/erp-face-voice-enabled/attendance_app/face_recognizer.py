import cv2
import face_recognition
import numpy as np
import os
import datetime
# Removed speech_recognition and pyttsx3 imports
# Removed threading import

from django.core.exceptions import ObjectDoesNotExist
from .models import Employee, AttendanceRecord

# Import BytesIO and pickle for serialization/deserialization
import io
import pickle


class FaceRecognitionSystem:
    def __init__(self, tolerance=0.6):
        self.known_encodings = []
        self.known_names = []
        self.known_employee_ids = []
        self.tolerance = tolerance
        # Removed initialization for text-to-speech engine and speech recognizer
        # Removed voice command processing flag
        self.load_known_faces()

    # Removed speak method

    # Removed listen_for_confirmation method

    def load_known_faces(self):
        """Load known face encodings and names from the database."""
        self.known_encodings = []
        self.known_names = []
        self.known_employee_ids = []
        employees = Employee.objects.all()
        for employee in employees:
            if employee.face_encoding:
                try:
                    loaded_encoding = pickle.loads(employee.face_encoding)
                    if isinstance(loaded_encoding, np.ndarray) and loaded_encoding.shape == (128,):
                        self.known_encodings.append(loaded_encoding)
                        self.known_names.append(employee.name)
                        self.known_employee_ids.append(employee.employee_id)
                        print(f"Loaded face for {employee.name}")
                    else:
                        print(f"Skipping {employee.name}: Invalid encoding format.")
                except (pickle.UnpicklingError, ValueError, TypeError) as e:
                    print(f"Error loading face encoding for {employee.name}: {e}")
            else:
                print(f"Employee {employee.name} has no face encoding stored.")
        print(f"Loading known faces... loaded {len(self.known_encodings)} faces.")

    def register_employee(self, emp_id):
        """
        Captures multiple face samples, averages their encodings,
        and saves the average encoding to the Employee model.
        """
        employee = None
        try:
            employee = Employee.objects.get(employee_id=emp_id)
        except ObjectDoesNotExist:
            # Replaced self.speak with a print statement for backend context
            print(f"Employee with ID {emp_id} not found. Please register employee details first.")
            return False

        print(f"Starting face registration for {employee.name}. Please look at the camera.")
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("Error: Could not open webcam.")
            return False

        face_samples = []
        captured_count = 0
        MAX_SAMPLES = 5
        print(f"Capturing {MAX_SAMPLES} face samples.")

        while captured_count < MAX_SAMPLES:
            ret, frame = cap.read()
            if not ret:
                print("Failed to grab frame")
                break

            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            face_locations = face_recognition.face_locations(rgb_frame)

            for (top, right, bottom, left) in face_locations:
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)

            # Display instructions
            instruction_text = f"Samples: {captured_count}/{MAX_SAMPLES}. Press 'C' to capture."
            cv2.putText(frame, instruction_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            cv2.putText(frame, "Press 'Q' to quit", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

            cv2.imshow('Register Employee - Face Capture', frame)
            key = cv2.waitKey(1) & 0xFF

            if key == ord('c') and face_locations:
                face_encoding = face_recognition.face_encodings(rgb_frame, face_locations)
                if face_encoding:
                    face_samples.append(face_encoding[0])
                    captured_count += 1
                    print(f"Captured sample {captured_count}")
                else:
                    print("No face detected in the frame. Please align your face.")
            elif key == ord('q'):
                print("Face registration cancelled by user.")
                break

        cap.release()
        cv2.destroyAllWindows()

        if face_samples:
            average_encoding = np.mean(face_samples, axis=0)
            employee.face_encoding = pickle.dumps(average_encoding)
            employee.save()
            self.load_known_faces()
            print(f"Face registration for {employee.name} complete.")
            return True
        else:
            print(f"No sufficient face samples captured for {employee.name}.")
            return False

    def recognize_face(self, frame):
        """Recognize faces in a given frame."""
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

        recognized_names = []
        for face_encoding in face_encodings:
            if not self.known_encodings:
                print("No known faces loaded for recognition.")
                return recognized_names

            matches = face_recognition.compare_faces(self.known_encodings, face_encoding, self.tolerance)
            name = "Unknown"

            face_distances = face_recognition.face_distance(self.known_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)
            if matches[best_match_index]:
                name = self.known_names[best_match_index]

            recognized_names.append(name)
        return recognized_names