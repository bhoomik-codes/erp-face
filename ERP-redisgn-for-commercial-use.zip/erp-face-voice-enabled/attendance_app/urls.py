from django.urls import path
from . import views # Import views from the current application

app_name = 'attendance_app' # Namespace for your app's URLs

urlpatterns = [
    # Employee Management URLs
    path('register/', views.register_employee, name='register_employee'),
    path('list/', views.employee_list, name='employee_list'),

    # Attendance Marking URLs
    path('mark/', views.mark_attendance, name='mark_attendance'),
    path('mark/capture/', views.mark_attendance_capture, name='mark_attendance_capture'),
    # NEW URL FOR CONFIRMATION
    path('process-speech-confirmation/', views.process_speech_confirmation, name='process_speech_confirmation'),

    path('recent-records/', views.recent_attendance_records, name='recent_attendance_records'),

    # For POST requests
    # Attendance Report URLs
    path('report/', views.attendance_report, name='attendance_report'),
    # Browser/server health check
    path('health/', views.health_check, name='health_check'),

    # Get current working hours
    path('get-current-working-hours/<str:employee_id>/<str:date>/',
         views.get_current_working_hours,
         name='get_current_working_hours'),
    path('check-face-position/', views.check_face_position, name='check_face_position'),
]
