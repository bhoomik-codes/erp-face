from django.db import models
from django.utils import timezone

class Employee(models.Model):
    name = models.CharField(
        max_length=100,
        help_text="Full name of the employee."
    )
    employee_id = models.CharField(
        max_length=50,
        unique=True,
        help_text="Unique identifier for the employee (e.g., staff ID)."
    )
    photo = models.ImageField(
        upload_to='employee_photos/',
        blank=False,
        null=False,
        help_text="A clear photo of the employee's face for recognition."
    )
    face_encoding = models.BinaryField(
        blank=True,
        null=True,
        help_text="Serialized face encoding derived from the employee's photo."
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_seen = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Last time the employee was recognized by the system."
    )

    def __str__(self):
        return f"{self.name} ({self.employee_id})"

    class Meta:
        app_label = 'attendance_app'  # <- Add this
        verbose_name = "Employee"
        verbose_name_plural = "Employees"
        ordering = ['name']

class AttendanceRecord(models.Model):

    ATTENDANCE_TYPES = [
        ('IN', 'In Time'),
        ('LUNCH_IN', 'Lunch In'),
        ('LUNCH_OUT', 'Lunch Out'),
        ('OUT', 'Out Time'),
        ('BREAK IN', 'Break In' ),
        ('BREAK OUT', 'Break Out')
    ]

    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='attendance_records',
        help_text="The employee associated with this attendance record."
    )
    date = models.DateField(
        default=timezone.now,
        help_text="The date when attendance was marked."
    )
    time = models.TimeField(
        default=timezone.now,
        help_text="The time when attendance was marked."
    )
    attendance_type = models.CharField(
        max_length=10,
        choices=ATTENDANCE_TYPES,
        default='IN'
    )

    remarks = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="Additional remarks (e.g., late entry, extended lunch)"
    )

    class Meta:
        app_label = 'attendance_app'  # <- Add this
        verbose_name = "Attendance Record"
        verbose_name_plural = "Attendance Records"
        ordering = ['-date', '-time']
        # Allow multiple records per day per employee
        unique_together = ['employee', 'date', 'attendance_type']

def __str__(self):
        return f"{self.employee.name} - {self.date} {self.time} ({self.attendance_type})"
