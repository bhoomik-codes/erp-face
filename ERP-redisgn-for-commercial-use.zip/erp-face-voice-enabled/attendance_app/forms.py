from django import forms
from .models import Employee

class EmployeeForm(forms.ModelForm):
    """
    Django ModelForm for creating and updating Employee instances.
    It automatically generates form fields based on the Employee model.
    """
    class Meta:
        model = Employee
        # Define the fields from the Employee model that should be included in the form.
        # 'face_encoding' is excluded as it's generated programmatically, not directly input by the user.
        fields = ['name', 'employee_id', 'photo']
        # You can add widgets for custom input types or attributes
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Enter full name'}),
            'employee_id': forms.TextInput(attrs={'placeholder': 'Unique ID'}),
        }
        # You can add help text for specific fields
        help_texts = {
            'photo': 'Upload a clear, front-facing photo of the employee for best recognition results.',
        }