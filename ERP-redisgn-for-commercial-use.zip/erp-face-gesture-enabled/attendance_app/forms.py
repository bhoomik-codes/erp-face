# attendance_app/forms.py
from django import forms
from django.contrib.auth.forms import AuthenticationForm
from .models import Employee, LocationSetting, CustomUser


class EmployeeForm(forms.ModelForm):
    """
    Form for creating and updating Employee records.
    Handles 'name', 'employee_id', 'photo', 'role', and 'team_members'.
    'face_encoding' is handled programmatically in the view based on 'photo'.
    """

    class Meta:
        model = Employee
        fields = ['name', 'employee_id', 'photo', 'role', 'team_members']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'placeholder': 'Employee Full Name'
            }),
            'employee_id': forms.TextInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'placeholder': 'Unique Employee ID'
            }),
            'photo': forms.FileInput(attrs={
                'class': 'block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100',
            }),
            'role': forms.Select(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
            }),
            # IMPORTANT CHANGE: Always render team_members as SelectMultiple, but make it hidden
            'team_members': forms.SelectMultiple(attrs={
                'class': 'hidden' # This class will hide the default Django widget
            }),
        }
        labels = {
            'name': 'Full Name',
            'employee_id': 'Employee ID',
            'photo': 'Profile Photo',
            'role': 'Role',
            'team_members': 'Team Members',
        }
        help_texts = {
            'photo': 'Upload a clear photo of the employee\'s face for recognition.',
            'role': 'Select the employee\'s role within the company.',
            'team_members': 'Select developers who work under this Team Leader. (Only applicable for Team Leaders)',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Dynamically set the queryset for team_members
        # This ensures only employees with specific roles are available for selection
        self.fields['team_members'].queryset = Employee.objects.filter(
            role__in=['TRAINEE', 'JUNIOR_DEVELOPER', 'SENIOR_DEVELOPER']
        ).order_by('name')

        # The 'team_members' field is always rendered as SelectMultiple now,
        # and its visibility is controlled by the 'hidden' class in Meta.widgets.
        self.fields['team_members'].required = False # Make it not required as it's optional


class AdminLoginForm(AuthenticationForm):
    """
    Custom login form for admin users.
    Inherits from Django's built-in AuthenticationForm.
    """
    username = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
            'placeholder': 'Username'
        })
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-shadow-outline',
            'placeholder': 'Password'
        })
    )

    class Meta:
        model = CustomUser
        fields = ['username', 'password']


class LocationSettingForm(forms.ModelForm):
    """
    Form for managing the single LocationSetting record.
    Used in admin settings to set geofencing parameters.
    """

    class Meta:
        model = LocationSetting
        fields = ['latitude', 'longitude', 'radius_meters']
        widgets = {
            'latitude': forms.NumberInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'step': 'any',
                'placeholder': 'e.g., 26.9124'
            }),
            'longitude': forms.NumberInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'step': 'any',
                'placeholder': 'e.g., 75.7873'
            }),
            'radius_meters': forms.NumberInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'min': '1',
                'placeholder': 'e.g., 500'
            }),
        }
        labels = {
            'latitude': 'Latitude',
            'longitude': 'Longitude',
            'radius_meters': 'Radius (meters)',
        }
