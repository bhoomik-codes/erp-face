# attendance_app/views/attendance_views.py
import base64
import json
import numpy as np
import cv2
import os
import time
import pytz
import requests
import threading
import urllib.parse
from datetime import datetime, date, timedelta, time  # Import time for time objects
from django.http import JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Max, Sum, F
from django.template.loader import render_to_string
from django.templatetags.static import static
from django.utils import timezone
from geopy.distance import geodesic
import logging

from ..services.attendance_manager import AttendanceManager
from ..face_recognizer import get_face_recognition_system
from ..forms import EmployeeForm
from ..models import Employee, AttendanceRecord, LocationSetting, LeaveHistory

logger = logging.getLogger(__name__)


@require_http_methods(["GET", "POST"])
@transaction.atomic
@login_required
def register_employee(request):
    """
    Handles employee registration (GET for form, POST for submission).
    Includes face encoding and now handles role and team members.
    """

    if request.method == 'POST':
        form = EmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            employee = form.save(commit=False) # Save the employee instance without committing to DB yet
            employee.save() # Now save the employee to the database to get an ID

            # Handle ManyToMany field 'team_members' after the employee is saved
            # This is only relevant if the employee's role is 'TEAM_LEADER'
            if employee.role == 'TEAM_LEADER':
                # Clear existing team members before setting new ones to handle updates
                # For new registration, this won't do anything as there are no existing members
                employee.team_members.clear()
                # Set the team members from the form's cleaned data
                # form.cleaned_data['team_members'] will be a QuerySet of selected Employees
                employee.team_members.set(form.cleaned_data['team_members'])
            else:
                # If the employee is not a Team Leader, ensure they have no team members
                employee.team_members.clear()


            face_recognition_system = get_face_recognition_system()

            if employee.photo:
                if face_recognition_system.register_employee(employee.employee_id):
                    logger.info(f"Employee {employee.name} ({employee.employee_id}) registered successfully with role {employee.role}.")
                    return redirect('attendance_app:employee_list')
                else:
                    logger.error(
                        f"Face registration failed for {employee.name} ({employee.employee_id}). Deleting record.")
                    # If face registration fails, delete the employee record to prevent orphaned data
                    if employee.photo and os.path.exists(employee.photo.path):
                        os.remove(employee.photo.path)
                    employee.delete() # Delete the employee record if face registration fails
                    form.add_error(None,
                                   "Face registration failed. Please ensure a clear face is visible and try again.")
            else:
                logger.warning(f"Attempted to register employee {employee.name} without a photo.")
                form.add_error('photo', "A profile photo is required for face recognition registration.")
                # If photo is missing and required, delete the employee record as it's incomplete
                employee.delete()
    else:
        form = EmployeeForm()

    return render(request, 'attendance_app/register_employee.html', {'form': form, 'current_page': 'register_employee'})


@login_required
def employee_list(request):
    """
    Displays a list of all registered employees.
    This will be the main employee management hub.
    """
    employees = Employee.objects.all().order_by('name')
    context = {
        'employees': employees,
        'current_page': 'employee_list'
    }
    return render(request, 'attendance_app/employee_list.html', context)


@require_http_methods(["GET", "POST"])
@transaction.atomic
@login_required
def employee_update(request, employee_id):
    """
    Handles updating an existing employee's details, including re-encoding face data if photo changes,
    and updating role and team members.
    """
    employee = get_object_or_404(Employee, employee_id=employee_id)
    face_recognition_system = get_face_recognition_system()

    if request.method == 'POST':
        original_photo_path = employee.photo.path if employee.photo else None
        original_face_encoding = employee.face_encoding  # Keep original encoding in case new one fails
        original_employee_id = employee.employee_id  # Store original ID for potential re-encoding/deletion
        original_role = employee.role # Store original role to check for changes

        form = EmployeeForm(request.POST, request.FILES, instance=employee)
        if form.is_valid():
            updated_employee = form.save(commit=False) # Save the employee instance without committing to DB yet

            # Check if employee_id is changed
            employee_id_changed = updated_employee.employee_id != original_employee_id
            if employee_id_changed:
                # If employee_id is changed, delete the old encoding and re-register with the new ID
                logger.info(f"Employee ID changed from {original_employee_id} to {updated_employee.employee_id}")
                face_recognition_system.delete_employee_encoding(original_employee_id)  # Delete old encoding

            photo_changed = 'photo' in request.FILES
            photo_cleared = form.cleaned_data.get('photo') is False

            # Save the employee first to ensure role and other fields are updated before handling M2M
            updated_employee.save()

            # Handle ManyToMany field 'team_members' after the employee is saved
            # This is only relevant if the employee's role is 'TEAM_LEADER'
            if updated_employee.role == 'TEAM_LEADER':
                # Set the team members from the form's cleaned data
                # .set() handles adding/removing relationships efficiently
                updated_employee.team_members.set(form.cleaned_data['team_members'])
            else:
                # If the employee is no longer a Team Leader, clear their team members
                updated_employee.team_members.clear()


            if photo_changed:
                if not face_recognition_system.register_employee(updated_employee.employee_id):
                    logger.error(
                        f"Failed to re-encode face for {updated_employee.name} (ID: {updated_employee.employee_id}) from new photo.")
                    # Revert photo and encoding in DB to original state if new encoding fails
                    if original_photo_path:
                        updated_employee.photo.name = os.path.basename(original_photo_path)  # Revert to old photo filename
                        updated_employee.face_encoding = original_face_encoding  # Revert to old encoding
                        updated_employee.save(update_fields=['photo', 'face_encoding'])
                        # If a new file was uploaded and failed, it might be in MEDIA_ROOT now. Clean it up.
                        new_photo_path = updated_employee.photo.path
                        if os.path.exists(new_photo_path) and new_photo_path != original_photo_path:
                            os.remove(new_photo_path)
                            logger.info(f"Cleaned up new failed photo file: {new_photo_path}")

                    form.add_error('photo',
                                   "Failed to re-encode face from new photo. Please ensure a clear face is visible.")
                    # IMPORTANT: Render with the current form (which contains user's submitted data)
                    return render(request, 'attendance_app/employee_update.html', {'form': form, 'employee': employee})
                else:
                    logger.info(
                        f"Face re-encoded successfully for {updated_employee.name} (ID: {updated_employee.employee_id}).")
                    if original_photo_path and os.path.exists(original_photo_path):
                        os.remove(original_photo_path)
                        logger.info(f"Deleted old photo file: {original_photo_path}")

            elif photo_cleared:
                if original_photo_path and os.path.exists(original_photo_path):
                    os.remove(original_photo_path)
                    logger.info(f"Deleted photo file: {original_photo_path} (photo cleared)")
                face_recognition_system.delete_employee_encoding(updated_employee.employee_id)
                updated_employee.face_encoding = None
                updated_employee.save(update_fields=['face_encoding'])
                logger.info(
                    f"Photo and face encoding cleared for {updated_employee.name} (ID: {updated_employee.employee_id}).")

            logger.info(f"Employee {updated_employee.name} (ID: {updated_employee.employee_id}) updated successfully with role {updated_employee.role}.")
            return redirect('attendance_app:employee_list')
    else:
        form = EmployeeForm(instance=employee)

    context = {
        'form': form,
        'employee': employee,
        'current_page': 'employee_update'
    }
    return render(request, 'attendance_app/employee_update.html', context)


@require_http_methods(["POST"])
@login_required
@transaction.atomic
def employee_delete(request, employee_id):
    """
    Handles deleting an employee record and their associated face encoding.
    """
    logger.info(f"Attempting to delete employee with ID: {employee_id}")
    try:
        employee = get_object_or_404(Employee, employee_id=employee_id)

        if employee.photo:
            if os.path.isfile(employee.photo.path):
                os.remove(employee.photo.path)
                logger.info(f"Deleted photo file for {employee.name} at {employee.photo.path}")

        face_recognition_system = get_face_recognition_system()
        face_recognition_system.delete_employee_encoding(employee.employee_id)

        employee.delete()
        logger.info(f"Employee {employee.name} (ID: {employee.employee_id}) deleted from database.")

        return JsonResponse({'status': 'success', 'message': f'Employee {employee_id} deleted successfully.'})
    except Exception as e:
        logger.exception(f"Error deleting employee {employee_id}:")
        return JsonResponse({'status': 'error', 'message': f'An error occurred during deletion: {str(e)}'}, status=500)


def mark_attendance(request):
    """
    Renders the main attendance marking page.
    """
    return render(request, 'attendance_app/mark_attendance.html')


@csrf_exempt
@require_http_methods(["POST"])
@transaction.atomic
def recognize_face_for_prompt(request):
    """
    API endpoint to receive image from frontend, perform face recognition,
    and return the recognized name. Does NOT mark attendance.
    """
    try:
        data = json.loads(request.body)
        image_data_url = data.get('image')

        if not image_data_url:
            logger.warning("Missing image data in recognize_face_for_prompt request.")
            return JsonResponse({'status': 'error', 'message': 'Missing image data.'}, status=400)

        header, encoded = image_data_url.split(",", 1)
        image_bytes = base64.b64decode(encoded)

        np_arr = np.frombuffer(image_bytes, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        if frame is None:
            logger.error("Could not decode image from base64 in recognize_face_for_prompt.")
            return JsonResponse({'status': 'error', 'message': 'Could not decode image from base64.'}, status=400)

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        face_recognition_system = get_face_recognition_system()
        recognized_names = face_recognition_system.recognize_face(rgb_frame)

        recognized_person_name = "Unknown"
        if recognized_names:
            recognized_person_name = recognized_names[0]
            logger.info(f"Face recognized: {recognized_person_name}")
        else:
            logger.info("Unknown face detected.")

        if recognized_person_name != "Unknown":
            return JsonResponse({'status': 'success', 'recognized_name': recognized_person_name,
                                 'message': f'Face recognized: {recognized_person_name}.'})
        else:
            return JsonResponse(
                {'status': 'info', 'message': 'Unknown person or invalid gesture.',
                 'recognized_name': recognized_person_name,
                 'is_late': False})

    except json.JSONDecodeError:
        logger.error("Invalid JSON data received in recognize_face_for_prompt.")
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON data.'}, status=400)
    except Exception as e:
        logger.exception("An internal server error occurred in recognize_face_for_prompt:")
        return JsonResponse({'status': 'error', 'message': f'An internal server error occurred: {str(e)}'}, status=500)


@csrf_exempt
@require_http_methods(["POST"])
@transaction.atomic
def mark_attendance_with_gesture(request):
    """
    API endpoint to receive recognized name, gesture, user's current location,
    and emotional state from frontend, and mark attendance based on these, with geofencing.
    """
    try:
        data = json.loads(request.body)
        recognized_name = data.get('recognized_name')
        gesture = data.get('gesture')
        user_latitude = data.get('latitude')
        user_longitude = data.get('longitude')
        emotional_state = data.get('emotional_state')

        logger.info(
            f"Received attendance request for {recognized_name} with gesture {gesture}. Emotion: {emotional_state}. Location: ({user_latitude}, {user_longitude})")

        if not recognized_name or not gesture:
            logger.warning("Missing recognized name or gesture in mark_attendance_with_gesture request.")
            return JsonResponse({'status': 'error', 'message': 'Missing recognized name or gesture.'}, status=400)

        ATTENDANCE_TRIGGER_GESTURES = ["Thumb_Up"]

        if recognized_name != "Unknown" and gesture in ATTENDANCE_TRIGGER_GESTURES:
            try:
                employee = Employee.objects.get(name=recognized_name)
            except Employee.DoesNotExist:
                logger.warning(f'Employee "{recognized_name}" not found in database for attendance marking.')
                return JsonResponse(
                    {'status': 'failure', 'message': f'Employee "{recognized_name}" not found in database.',
                     'recognized_name': recognized_name})

            office_setting = LocationSetting.objects.first()
            location_check_message_suffix = ""

            if office_setting and user_latitude is not None and user_longitude is not None:
                try:
                    office_coords = (float(office_setting.latitude), float(office_setting.longitude))
                    user_coords = (float(user_latitude), float(user_longitude))
                    distance_meters = geodesic(office_coords, user_coords).meters

                    logger.debug(f"Office Coords: {office_coords}, User Coords: {user_coords}")
                    logger.debug(
                        f"Calculated distance: {distance_meters:.2f}m, Allowed radius: {office_setting.radius_meters}m")

                    if distance_meters > office_setting.radius_meters:
                        logger.info(
                            f"Employee {employee.name} attempted to mark attendance outside geofence. Distance: {distance_meters:.2f}m")
                        return JsonResponse({
                            'status': 'info',
                            'message': f'You are {int(distance_meters)}m away from the office. Attendance can only be marked within {office_setting.radius_meters}m.',
                            'recognized_name': employee.name,
                            'is_late': False,
                            'attendance_type': None
                        })
                except ValueError as ve:
                    logger.error(
                        f"Invalid float conversion for location data during geofencing: {ve}. User Lat: {user_latitude}, User Lng: {user_longitude}")
                    location_check_message_suffix = " (Location check skipped: Invalid coordinates provided or configured)."
                except Exception as geo_e:
                    logger.exception(f"Error during geofencing check for {employee.name}:")
                    location_check_message_suffix = f" (Location check failed due to an error: {str(geo_e)})."
            else:
                if not office_setting:
                    location_check_message_suffix = " (No office location set by admin, location check skipped)."
                elif user_latitude is None or user_longitude is None:
                    location_check_message_suffix = " (Your device location not available, location check skipped)."

            attendance_type, message, is_late = AttendanceManager.determine_attendance_type(employee)
            if attendance_type:
                AttendanceManager.create_attendance_record(employee, attendance_type, remarks=message,
                                                           emotional_state=emotional_state if attendance_type == 'IN' else None)

            logger.info(
                f"Attendance marked for {employee.name} as {attendance_type}. Message: {message}{location_check_message_suffix}")
            return JsonResponse({
                "status": "success",
                "message": message + location_check_message_suffix,
                "recognized_name": employee.name,
                "attendance_type": attendance_type,
                "is_late": is_late
            })
        else:
            logger.info(f"Unknown person or invalid gesture: {recognized_name}, {gesture}")
            return JsonResponse(
                {'status': 'info', 'message': 'Unknown person or invalid gesture.', 'recognized_name': recognized_name,
                 'is_late': False})

    except json.JSONDecodeError:
        logger.error("Invalid JSON data received in mark_attendance_with_gesture.")
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON data.'}, status=400)
    except Exception as e:
        logger.exception("An internal server error occurred in mark_attendance_with_gesture:")
        return JsonResponse({'status': 'error', 'message': f'An internal server error occurred: {str(e)}'}, status=500)


@require_http_methods(["GET"])
def recent_attendance_records(request):
    """
    Fetches and displays recent attendance records as cards.
    """
    try:
        cutoff_date = timezone.localdate() - timedelta(days=7)
        logger.debug(f"Cutoff date for recent records: {cutoff_date}")

        # Get the top 10 distinct employees with the most recent 'last_seen' timestamp
        # This avoids complex date/time arithmetic in the annotation
        recent_employees_with_latest_activity = Employee.objects.filter(
            last_seen__gte=cutoff_date  # Filter by last_seen to ensure recent activity
        ).order_by('-last_seen')[:10]

        data = []
        for employee in recent_employees_with_latest_activity:
            # For each recent employee, find their actual latest attendance record on any date
            # This is to get the specific IN/OUT times for the card.
            employee_latest_record_overall = AttendanceRecord.objects.filter(
                employee=employee
            ).order_by('-date', '-time').first()

            if not employee_latest_record_overall:
                logger.warning(
                    f"No overall attendance record found for employee {employee.employee_id} after filtering by last_seen.")
                continue

            latest_date_for_employee = employee_latest_record_overall.date

            try:
                # Fetch all records for this specific employee on *that latest day*
                daily_records = AttendanceRecord.objects.filter(
                    employee=employee,
                    date=latest_date_for_employee
                ).order_by('time')

                in_record = daily_records.filter(attendance_type='IN').first()
                out_record = daily_records.filter(attendance_type='OUT').first()
                lunch_in_record = daily_records.filter(attendance_type='LUNCH_IN').first()
                lunch_out_record = daily_records.filter(attendance_type='LUNCH_OUT').first()
                # Corrected "BREAK IN" to "BREAK_IN" and "BREAK OUT" to "BREAK_OUT" for consistency
                break_in_record = daily_records.filter(attendance_type='BREAK_IN').first()
                break_out_record = daily_records.filter(attendance_type='BREAK_OUT').first()

                remarks_list = [r.remarks for r in
                                daily_records.exclude(remarks__isnull=True).exclude(remarks__exact='')]
                combined_remarks = "; ".join(remarks_list) if remarks_list else None

                is_late_for_record_display = False
                if in_record and in_record.time and in_record.time > AttendanceManager.IN_TIME_END:
                    is_late_for_record_display = True

                # Calculate total working hours here for recent records display
                total_hours_recent, _, _, has_out_recent = AttendanceManager.calculate_working_hours(employee,
                                                                                                     latest_date_for_employee)

                data.append({
                    'employee_name': employee.name,
                    'employee_id': employee.employee_id,
                    'photo_url': employee.photo.url if employee.photo else static('img/default_avatar.png'),
                    'date': latest_date_for_employee.strftime('%Y-%m-%d'),
                    'in_time': in_record.time.strftime('%I:%M %p') if in_record else None,
                    'out_time': out_record.time.strftime('%I:%M %p') if out_record else None,
                    'lunch_in_time': lunch_in_record.time.strftime('%I:%M %p') if lunch_in_record else None,
                    'lunch_out_time': lunch_out_record.time.strftime('%I:%M %p') if lunch_out_record else None,
                    'break_in_time': break_in_record.time.strftime('%I:%M %p') if break_in_record else None,
                    'break_out_time': break_out_record.time.strftime('%I:%M %p') if break_out_record else None,
                    'total_working_hours': f"{total_hours_recent} hours" if has_out_recent or (
                            latest_date_for_employee != date.today()) else 'In progress...',
                    'remarks': combined_remarks,
                    'is_late': is_late_for_record_display,
                    'emotional_state': in_record.emotional_state if in_record else None,
                })
            except Employee.DoesNotExist:
                logger.warning(
                    f"Employee with ID {employee.employee_id} not found during final lookup for recent records. This shouldn't happen if filtered by last_seen correctly.")
                continue

        # Sort the final data list by date and time to ensure true recency
        # This sort is now done on the Python list, which is safer.
        data.sort(key=lambda x: (
            datetime.strptime(x['date'], '%Y-%m-%d').date(),  # Parse date string to date object
            datetime.strptime(x['in_time'], '%I:%M %p').time() if x['in_time'] else time.min
        # Parse time string to time object, handle None
        ), reverse=True)  # Keep reverse=True for latest date and latest time first

        logger.info(f"Successfully fetched {len(data)} recent attendance records.")
        records_html = render_to_string(
            'attendance_app/partials/recent_records.html',
            {'records': data},
            request=request
        )
        return JsonResponse({'status': 'success', 'records_html': records_html})
    except Exception as e:
        logger.exception("Error fetching recent attendance records:")
        return JsonResponse({'status': 'error', 'message': f'Failed to fetch recent records: {str(e)}'}, status=500)


@require_http_methods(["GET"])
def get_current_working_hours(request, employee_id, date_str):
    """
    API endpoint to get real-time working hours for a single employee on a specific date.
    """
    try:
        employee = get_object_or_404(Employee, employee_id=employee_id)
        target_date = datetime.strptime(date_str, '%Y-%m-%d').date()

        total_hours, lunch_duration, break_duration, has_out = AttendanceManager.calculate_working_hours(employee,
                                                                                                         target_date)
        logger.debug(
            f"Working hours for {employee_id} on {date_str}: {total_hours} hrs, Lunch: {lunch_duration} hrs, Break: {break_duration} hrs, Has Out: {has_out}")
        return JsonResponse({
            'employee_id': employee_id,
            'date': date_str,
            'total_working_hours': total_hours,
            'lunch_duration': lunch_duration,
            'break_duration': break_duration,
            'has_out': has_out
        })
    except Employee.DoesNotExist:
        logger.warning(f"Employee {employee_id} not found when fetching working hours.")
        return JsonResponse({"status": "error", "message": "Employee not found."}, status=404)
    except ValueError:
        logger.error(f"Invalid date format received for working hours: {date_str}")
        return JsonResponse({"status": "error", "message": "Invalid date format."}, status=400)
    except Exception as e:
        logger.exception(f"Error getting current working hours for {employee_id} on {date_str}:")
        return JsonResponse({"status": "error", "message": str(e)}, status=500)


@require_http_methods(["GET"])
def get_rendered_attendance_table(request):
    """
    API endpoint to return the fully rendered HTML tbody content
    based on the current filters. This will be used for AJAX updates.
    """
    filter_start_date_str = request.GET.get('start_date')
    filter_end_date_str = request.GET.get('end_date')
    filter_employee_ids_list = request.GET.getlist('employee_ids[]')
    filter_attendance_type = request.GET.get('attendance_type')
    filter_total_hours_lt = request.GET.get('total_hours_lt')

    attendance_summary = AttendanceManager.get_filtered_attendance_summary(
        filter_start_date_str, filter_end_date_str, filter_employee_ids_list,
        filter_attendance_type, filter_total_hours_lt
    )

    rendered_html = render_to_string('attendance_app/partials/attendance_table_body.html', {
        'attendance_records': attendance_summary,
        'static': static
    })

    return JsonResponse({'html': rendered_html})


@require_http_methods(["GET"])
def get_employee_leaves(request, employee_id):
    """
    API endpoint to fetch leave information for a specific employee.
    """
    try:
        employee = get_object_or_404(Employee, employee_id=employee_id)
        logger.debug(f"Fetching leave info for Employee ID: {employee.employee_id}, Name: {employee.name}")
        current_date = date.today()
        current_year = current_date.year
        current_month_number = current_date.month

        # Accrue 1 leave per month
        total_leaves_accrued_this_year = current_month_number

        leaves_taken_this_year_query = LeaveHistory.objects.filter(
            employee=employee,
            month__startswith=str(current_year)
        ).aggregate(Sum('leaves_taken'))

        leaves_taken_this_year = leaves_taken_this_year_query['leaves_taken__sum'] or 0

        leaves_remaining = total_leaves_accrued_this_year - leaves_taken_this_year

        if leaves_remaining < 0:
            leaves_remaining = 0

        response_data = {
            'employeeId': employee.employee_id,
            'employeeName': employee.name,
            'totalLeavesAccruedThisYear': total_leaves_accrued_this_year,
            'leavesTakenThisYear': leaves_taken_this_year,
            'leavesRemaining': leaves_remaining,
            'currentMonth': f"{current_year}-{current_month_number:02d}"
        }
        logger.info(f"Leave info for {employee.name} ({employee.employee_id}): {response_data}")
        return JsonResponse(response_data)

    except Employee.DoesNotExist:
        logger.warning(f'Employee with ID "{employee_id}" not found for leave lookup.')
        return JsonResponse({'error': f'Employee with ID "{employee_id}" not found.'}, status=404)
    except Exception as e:
        logger.exception(f"Error in get_employee_leaves for employee {employee_id}:")
        return JsonResponse({'error': 'An internal server error occurred while processing your request.'}, status=500)
