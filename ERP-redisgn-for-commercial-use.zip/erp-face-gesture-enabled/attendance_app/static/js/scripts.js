// This section should be uncommented and configured if you are using MediaPipe libraries
// for Gesture Recognition. Ensure you have the MediaPipe Tasks Vision library accessible.
import {
    GestureRecognizer,
    FilesetResolver,
    DrawingUtils
} from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.3";

// Face-API.js is now loaded globally via CDN in mark_attendance.html
// Accessing it via window.faceapi to ensure it's defined within the module scope.

const demosSection = document.getElementById("demos");
const loadingDiv = document.getElementById("loading");
let gestureRecognizer; // Variable to hold the gesture recognizer instance
let runningMode = "VIDEO"; // Set to VIDEO mode for live stream
let webcamRunning = false;
const videoHeight = "480px"; // These are hints, canvas will adapt to video dimensions
const videoWidth = "640px"; // These are hints, canvas will adapt to video dimensions

// Correctly identify elements from mark_attendance.html
const video = document.getElementById("webcam");
const canvasElement = document.getElementById("output_canvas");
const canvasCtx = canvasElement.getContext("2d");
const gestureOutput = document.getElementById("gesture_output"); // Used for console debugging, hidden from UI
const statusMessage = document.getElementById("status_message"); // Main status message area
const employeeIdDisplay = document.getElementById('employeeIdDisplay'); // Display for recognized employee ID
const recentRecordsScrollContainer = document.getElementById('recentRecordsScrollContainer'); // Container for recent records
const noRecentRecordsMessage = document.getElementById('noRecentRecordsMessage'); // Message for no recent records
const currentDateTimeElement = document.getElementById('currentDateTime'); // Element for current date/time in header
const cameraButton = document.getElementById('cameraButton'); // New camera button

// Global variables for Face-API.js and emotion
let currentEmotion = null; // Stores the detected emotion, for backend only

// --- State Management ---
// Define possible states for the attendance system
const SYSTEM_STATE = {
    INITIAL: 'INITIAL', // Initial state, waiting for models/webcam
    FACE_RECOGNIZING: 'FACE_RECOGNIZING', // Actively trying to recognize a face
    MULTIPLE_FACES_DETECTED: 'MULTIPLE_FACES_DETECTED', // New state for multiple faces

    FACE_RECOGNIZED_PROMPT_GESTURE: 'FACE_RECOGNIZED_PROMPT_GESTURE', // Face recognized, waiting for gesture
    ATTENDANCE_PROCESSING: 'ATTENDANCE_PROCESSING' // Marking attendance, waiting for backend response
};
let currentSystemState = SYSTEM_STATE.INITIAL;
let recognizedEmployeeName = null; // Stores the name of the last recognized
let recognizedPopupShown = false;
let lastFaceRecognitionTime = 0; // Timestamp for last face recognition attempt (for cooldown)
const FACE_RECOGNITION_COOLDOWN_SECONDS = 5; // Cooldown period for initiating face recognition

// Define the gesture that triggers attendance marking
const ATTENDANCE_TRIGGER_GESTURE = "Thumb_Up";
let lastAttendanceMarkedTime = 0; // Timestamp for the last successful attendance mark (for cooldown)
const ATTENDANCE_COOLDOWN_SECONDS = 10; // Cooldown period after marking attendance for the same person

// New variable to control single face scanning
let isScanningAllowed = false; // Initialized to false to wait for spacebar press
let noFaceDetectedAttempts = 0;    // counts consecutive no‑face frames

// New variable for periodic voice prompts
let lastSpeechPromptTime = 0;
const SPEECH_PROMPT_INTERVAL_SECONDS = 60; // 1 minute

// --- State Transition Logging Function ---
function setSystemState(newState) {
    if (currentSystemState !== newState) {
        console.log(`➡️ SYSTEM STATE CHANGE: ${currentSystemState} -> ${newState}`);
        currentSystemState = newState;
    }
}


// --- Speech Synthesis Utility ---
// Function to make the browser speak text
function speak(text) {
    console.log(`🗣️ Speech requested: "${text}"`);
    return new Promise(resolve => {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.onend = () => {
                console.log("🗣️ Speech finished.");
                resolve();
            };
            utterance.onerror = (event) => {
                console.error("❌ Speech synthesis error:", event);
                resolve();
            };
            speechSynthesis.speak(utterance);
        } else {
            console.warn("Speech synthesis not supported in this browser.");
            resolve();
        }
    });
}

// Function to update the status message displayed on the UI
function updateStatusMessage(type, message = "No message provided.") {
    if (statusMessage) {
        statusMessage.textContent = message;
        statusMessage.classList.remove('status-info', 'status-success', 'status-warning', 'status-error', 'status-no-face'); // Added status-no-face
        switch (type) {
            case 'info':
                statusMessage.classList.add('status-info');
                break;
            case 'success':
                statusMessage.classList.add('status-success');
                break;
            case 'warning':
                statusMessage.classList.add('status-warning');
                break;
            case 'error':
                statusMessage.classList.add('status-error');
                break;
            case 'no_face': // New case for no face
                statusMessage.classList.add('status-no-face');
                break;
            default:
                statusMessage.classList.add('status-info');
                break;
        }
    }
}

// --- Face Position Check ---
function checkFacePosition(detection) {
    if (!detection || !video) {
        return {status: 'no_face', message: 'No face detected.'};
    }

    const videoWidth = video.videoWidth;
    const videoHeight = video.videoHeight;
    const box = detection.box;

    const centralRegionXStart = videoWidth * 0.25;
    const centralRegionXEnd = videoWidth * 0.75;
    const centralRegionYStart = videoHeight * 0.20;
    const centralRegionYEnd = videoHeight * 0.80;

    const faceCenterX = box.x + box.width / 2;
    const faceCenterY = box.y + box.height / 2;

    const isCentered = (faceCenterX > centralRegionXStart && faceCenterX < centralRegionXEnd) &&
        (faceCenterY > centralRegionYStart && faceCenterY < centralRegionYEnd);

    const minFaceSize = Math.min(videoWidth, videoHeight) * 0.20;
    const maxFaceSize = Math.min(videoWidth, videoHeight) * 0.70;

    const faceSize = Math.max(box.width, box.height);

    let message = "Please position your face within the frame.";
    let status = 'info';

    if (faceSize < minFaceSize) {
        message = "Move closer to the camera.";
        status = 'warning';
    } else if (faceSize > maxFaceSize) {
        message = "Move further from the camera.";
        status = 'warning';
    } else if (!isCentered) {
        let horizontalMsg = "";
        let verticalMsg = "";
        if (faceCenterX < centralRegionXStart) horizontalMsg = "Move right. ";
        else if (faceCenterX > centralRegionXEnd) horizontalMsg = "Move left. ";

        if (faceCenterY < centralRegionYStart) verticalMsg = "Move down.";
        else if (faceCenterY > centralRegionYEnd) verticalMsg = "Move up.";

        if (horizontalMsg || verticalMsg) {
            message = `Center your face. ${horizontalMsg}${verticalMsg}`;
            status = 'warning';
        } else {
            message = "Adjust your position slightly.";
            status = 'warning';
        }
    } else {
        message = "Face is positioned correctly.";
        status = 'centered';
    }
    return {status, message};
}


// --- Face-API.js Model Loading ---
async function loadFaceApiModels() {
    loadingDiv.classList.remove("hidden");
    updateStatusMessage('info', "Loading AI models...");
    try {
        while (typeof window.faceapi === 'undefined') {
            console.log("Waiting for window.faceapi to load...");
            await new Promise(resolve => setTimeout(resolve, 100));
        }

        const MODEL_URL = '/static/models';
        await window.faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
        await window.faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
        await window.faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
        await window.faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL);

        console.log("✅ Face-API.js models loaded successfully.");
        updateStatusMessage('info', "Models loaded. Starting webcam...");
        loadingDiv.classList.add("hidden");
    } catch (error) {
        console.error("❌ Error loading Face-API.js models:", error);
        updateStatusMessage('error', "Error loading face recognition models. Please check your internet connection and ensure models are in '/static/models'.");
        loadingDiv.classList.add("hidden");
        // Potentially disable webcam or system functionality here if models are crucial
        webcamRunning = false;
        setSystemState(SYSTEM_STATE.INITIAL);
    }
}


// --- MediaPipe Gesture Recognizer Setup ---
const createGestureRecognizer = async () => {
    console.log("🛠️ Initializing Gesture Recognizer...");
    updateStatusMessage('info', "Initializing gesture recognition...");
    try {
        const vision = await FilesetResolver.forVisionTasks(
            "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.3/wasm"
        );
        console.log("Fetched MediaPipe WASM files.");
        gestureRecognizer = await GestureRecognizer.createFromOptions(vision, {
            baseOptions: {
                modelAssetPath:
                    "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task",
                delegate: "GPU"
            },
            runningMode: runningMode,
            numHands: 1,
            minDetectionConfidence: 0.7,
            minTrackingConfidence: 0.7,
            minResultConfidence: 0.1
        });
        console.log("Gesture Recognizer initialized.");
        if (loadingDiv) loadingDiv.classList.add("hidden");
        if (demosSection) demosSection.classList.remove("invisible");
        updateStatusMessage('info', "Gesture recognizer ready. Starting webcam...");
        console.log("✅ Gesture Recognizer loaded successfully.");
        await enableCam(); // Only enable camera AFTER all models are loaded

    } catch (error) {
        console.error("❌ Failed to load Gesture Recognizer:", error);
        updateStatusMessage('error', "Error loading gesture recognition model. Please refresh the page.");
        webcamRunning = false;
        setSystemState(SYSTEM_STATE.INITIAL);
    }
};

function hasGetUserMedia() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
}

async function enableCam() {
    console.log(`🎥 enableCam called. Current webcamRunning: ${webcamRunning}`);
    if (!gestureRecognizer || typeof window.faceapi === 'undefined' || loadingDiv && !loadingDiv.classList.contains("hidden")) {
        updateStatusMessage('info', "Please wait for all system components to initialize.");
        console.log("ℹ️ Gesture Recognizer or Face-API.js models not fully ready, waiting.");
        return;
    }

    if (webcamRunning === true) {
        console.log("Stopping webcam...");
        webcamRunning = false;
        if (video.srcObject) {
            video.srcObject.getTracks().forEach(track => {
                console.log(`Stopping track: ${track.kind}`);
                track.stop();
            });
        }
        video.srcObject = null;
        canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
        if (gestureOutput) gestureOutput.style.display = "none";
        if (employeeIdDisplay) employeeIdDisplay.textContent = 'Waiting for scan...';
        updateStatusMessage('info', "Webcam stopped. Refresh page to restart.");
        setSystemState(SYSTEM_STATE.INITIAL);
        recognizedEmployeeName = null;
        currentEmotion = null;
        console.log("🚫 Webcam stopped. System state reset to INITIAL.");
    } else {
        webcamRunning = true;
        updateStatusMessage('info', "Requesting camera access...");
        if (employeeIdDisplay) employeeIdDisplay.textContent = 'Scanning...';
        console.log("🚀 Starting webcam and requesting camera access...");

        const constraints = {video: true};
        try {
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            video.srcObject = stream;
            video.onloadedmetadata = () => {
                video.play();
                predictWebcam();
            };
            updateStatusMessage('info', "Webcam enabled. Press Spacebar or Camera button to start scanning for faces.");
            setSystemState(SYSTEM_STATE.FACE_RECOGNIZING);
            recognizedPopupShown = false;
            isScanningAllowed = false;
            console.log("✅ Webcam access granted. System state set to FACE_RECOGNIZING. Scanning paused, press Spacebar or Camera button to start.");
        } catch (err) {
            console.error("❌ Error accessing webcam: ", err);
            updateStatusMessage('error', "Error: Could not access webcam. Please allow camera access and refresh.");
            webcamRunning = false;
            setSystemState(SYSTEM_STATE.INITIAL);
            console.log("🚫 Webcam access denied. System state reset to INITIAL.");
        }
    }
}

let lastVideoTime = -1;
let gestureResults = undefined;

async function predictWebcam() {
    canvasElement.width = video.videoWidth;
    canvasElement.height = video.videoHeight;

    let nowInMs = Date.now();

    if (video.currentTime !== lastVideoTime) {
        lastVideoTime = video.currentTime;
        if (gestureRecognizer) {
            gestureResults = gestureRecognizer.recognizeForVideo(video, nowInMs);
        }
    }

    canvasCtx.save();
    canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
    canvasCtx.drawImage(video, 0, 0, canvasElement.width, canvasElement.height);
    canvasCtx.translate(canvasElement.width, 0);
    canvasCtx.scale(-1, 1);

    // Drawing Hand Landmarks (for console debugging, commented out from UI)
    if (webcamRunning && gestureResults && gestureResults.landmarks && gestureResults.landmarks.length > 0) {
        const drawingUtils = new DrawingUtils(canvasCtx);
        // for (const handLandmarks of gestureResults.landmarks) {
        //     drawingUtils.drawConnectors(
        //         handLandmarks,
        //         GestureRecognizer.HAND_CONNECTIONS,
        //         { color: "#00FF00", lineWidth: 5 }
        //     );
        //     drawingUtils.drawLandmarks(handLandmarks, {
        //         color: "#FF0000",
        //         lineWidth: 2
        //     });
        // }
    }

    let detections = []; // Changed to an array for multiple detections
    if (webcamRunning && typeof window.faceapi !== 'undefined' && isScanningAllowed) {
        try {
            // Detect ALL faces
            detections = await window.faceapi.detectAllFaces(video, new window.faceapi.TinyFaceDetectorOptions())
                .withFaceLandmarks()
                .withFaceExpressions();

            if (detections.length > 1) {
                // Multiple faces detected
                setSystemState(SYSTEM_STATE.MULTIPLE_FACES_DETECTED);
                updateStatusMessage('warning', 'Multiple faces detected! Please ensure only one person is in front of the camera.');
                employeeIdDisplay.textContent = 'Multiple Faces';
                currentEmotion = null; // Clear emotion as it's ambiguous
                window.faceapi.draw.drawDetections(canvasElement, window.faceapi.resizeResults(detections, {
                    width: canvasElement.width,
                    height: canvasElement.height
                }));
                // Pause scanning until only one face is present or re-scan is triggered
                isScanningAllowed = false;
                recognizedEmployeeName = null;
                recognizedPopupShown = false;
            } else if (detections.length === 1) {
                // Single face detected
                setSystemState(SYSTEM_STATE.FACE_RECOGNIZING); // Revert to recognizing if previously multiple
                noFaceDetectedAttempts = 0;
                const resizedDetections = window.faceapi.resizeResults(detections[0], { // Use detections[0] for single face
                    width: canvasElement.width,
                    height: canvasElement.height
                });

                window.faceapi.draw.drawDetections(canvasElement, resizedDetections);

                const expressions = resizedDetections.expressions;
                if (expressions) {
                    const sortedExpressions = Object.keys(expressions).sort((a, b) => expressions[b] - expressions[a]);
                    currentEmotion = sortedExpressions[0];
                    console.log("📊 Detected Emotion:", currentEmotion);
                }

                const facePositionStatus = checkFacePosition(resizedDetections.detection);
                // Only update status if it's not a warning or error related to multiple faces
                if (currentSystemState !== SYSTEM_STATE.MULTIPLE_FACES_DETECTED) {
                    updateStatusMessage(facePositionStatus.status, facePositionStatus.message);
                }

            } else {
                // No faces detected
                if (currentSystemState !== SYSTEM_STATE.MULTIPLE_FACES_DETECTED) { // Don't override multiple face message
                    noFaceDetectedAttempts++;
                    if (noFaceDetectedAttempts >= 2) {
                        updateStatusMessage('no_face', 'No face detected. Press Spacebar or Camera button to re-scan.');
                        employeeIdDisplay.textContent = 'Waiting for scan...';
                    }
                }
                currentEmotion = null;
            }
        } catch (faceApiError) {
            console.error("❌ Error during Face-API.js detection:", faceApiError);
            updateStatusMessage('error', 'Error during face detection. Models might not be fully ready or a webcam issue occurred.');
        }
    } else if (!isScanningAllowed) {
        if (currentSystemState === SYSTEM_STATE.FACE_RECOGNIZING) {
            employeeIdDisplay.textContent = 'Waiting for scan...';
            updateStatusMessage("info", "Scanning... Please wait few seconds. If it takes longer than 10 seconds, please press spacebar again.");
        }
        if (currentSystemState === SYSTEM_STATE.FACE_RECOGNIZED_PROMPT_GESTURE) {
            console.log("Prompt...")
            employeeIdDisplay.textContent = 'Waiting for scan...';
        }
        if (currentSystemState === SYSTEM_STATE.ATTENDANCE_PROCESSING) {
            console.log("Processing...")
        }
        if (currentSystemState !== SYSTEM_STATE.MULTIPLE_FACES_DETECTED) { // Don't override if multiple faces
            employeeIdDisplay.textContent = 'Ready to scan.';
        }
        currentEmotion = null;
    }


    canvasCtx.restore();
    canvasElement.style.display = "block";

    let currentGesture = null;
    if (webcamRunning && gestureResults && gestureResults.gestures && gestureResults.gestures.length > 0
        &&
        gestureResults.gestures[0] && gestureResults.gestures[0][0].score >= 0.5) {
        currentGesture = gestureResults.gestures[0][0].categoryName;
        // if (gestureOutput) { gestureOutput.style.display = "block"; gestureOutput.innerText = `Detected Gesture: ${currentGesture} (Conf: ${parseFloat(gestureResults.gestures[0][0].score * 100).toFixed(2)}%)`; }
        // console.log(`🖐️ Detected Gesture: ${currentGesture} (Conf: ${parseFloat(gestureResults.gestures[0][0].score * 100).toFixed(2)}%)`); // Commented out for now
    }

    const currentTime = Date.now();

    // Periodic voice prompt
    if (currentSystemState === SYSTEM_STATE.FACE_RECOGNIZING && !isScanningAllowed && (currentTime - lastSpeechPromptTime) > (SPEECH_PROMPT_INTERVAL_SECONDS * 1000)) {
        speak("Press spacebar or camera button to initiate face scan for attendance.");
        lastSpeechPromptTime = currentTime;
    }


    switch (currentSystemState) {
        case SYSTEM_STATE.FACE_RECOGNIZING:
            if (isScanningAllowed && detections.length === 1) { // Only proceed if single face and scanning allowed
                const facePosStatus = (detections[0] && detections[0].detection) ? checkFacePosition(detections[0].detection).status : 'no_face';
                const cooldownPassed = (currentTime - lastFaceRecognitionTime) > (FACE_RECOGNITION_COOLDOWN_SECONDS * 1000);

                console.log(`[STATE: FACE_RECOGNIZING] Face Pos: ${facePosStatus}, Emotion: ${currentEmotion}, Cooldown Passed: ${cooldownPassed}, Scanning Allowed: ${isScanningAllowed}`);

                if (currentEmotion !== null && facePosStatus === 'centered' && cooldownPassed) {
                    console.log(`[ACTION] Triggering backend face recognition.`);
                    lastFaceRecognitionTime = currentTime;
                    const imageDataUrl = captureFrame(video);
                    recognizeFaceOnBackend(imageDataUrl);
                    isScanningAllowed = false; // Pause scanning after sending to backend
                } else if (currentEmotion === null) {
                    // This block is now mostly handled by the detections.length check above
                    // updateStatusMessage('no_face', 'No face detected. Please position yourself in front of the camera.');
                    // employeeIdDisplay.textContent = 'Waiting for scan...';
                    // recognizedEmployeeName = null;
                } else if (!cooldownPassed) {
                    const timeLeft = FACE_RECOGNITION_COOLDOWN_SECONDS - Math.floor((currentTime - lastFaceRecognitionTime) / 1000);
                    updateStatusMessage('info', `Scanning... Please wait ${timeLeft} seconds.`);
                }
            } else if (!isScanningAllowed && detections.length === 0) {
                employeeIdDisplay.textContent = 'Ready to scan.';
            }
            break;

        case SYSTEM_STATE.MULTIPLE_FACES_DETECTED:
            updateStatusMessage('error', 'Multiple faces detected! Please ensure only one person is in front of the camera.');
            employeeIdDisplay.textContent = 'Multiple Faces';
            // Speak only once per detection event
            if (!recognizedPopupShown) { // Re-using recognizedPopupShown for one-time prompt
                speak("Multiple faces detected. Please ensure only one person is in front of the camera.");
                recognizedPopupShown = true;
                setTimeout(() => recognizedPopupShown = false, 5000); // Cooldown for the spoken prompt
            }
            break;

        case SYSTEM_STATE.FACE_RECOGNIZED_PROMPT_GESTURE:
            console.log(`[STATE: FACE_RECOGNIZED_PROMPT_GESTURE] Recognized: ${recognizedEmployeeName}. Automatically marking attendance.`);
            const displayEmployeeName = recognizedEmployeeName.replace("_spoken_prompt", ""); // Clean name for display
            employeeIdDisplay.textContent = `Recognized: ${displayEmployeeName}`;
            updateStatusMessage('success', `Welcome ${displayEmployeeName}! Marking attendance automatically.`);

            // Show recognized face popup
            if (!recognizedPopupShown) {
                recognizedFacePopup(displayEmployeeName);
                recognizedPopupShown = true;
            }

            // Speak prompt if not already spoken (and remove "_spoken_prompt" marker)
            if (!recognizedEmployeeName.includes("_spoken_prompt") && (currentTime - lastSpeechPromptTime) > (SPEECH_PROMPT_INTERVAL_SECONDS * 1000 / 2)) {
                speak(`Welcome ${displayEmployeeName}! Marking your attendance.`);
                lastSpeechPromptTime = currentTime;
                recognizedEmployeeName += "_spoken_prompt"; // Mark that prompt has been spoken
            }

            // --- AUTOMATIC ATTENDANCE MARKING (GESTURE BYPASSED) ---
            if ((currentTime - lastAttendanceMarkedTime) > (ATTENDANCE_COOLDOWN_SECONDS * 1000)) {
                console.log(`[ACTION] Attendance cooldown passed. Marking attendance automatically.`);
                setSystemState(SYSTEM_STATE.ATTENDANCE_PROCESSING);
                updateStatusMessage('info', `Marking attendance...`);
                // Capture location before sending attendance request
                navigator.geolocation.getCurrentPosition(position => {
                    const userLatitude = position.coords.latitude;
                    const userLongitude = position.coords.longitude;
                    // Changed "AutoMark" back to ATTENDANCE_TRIGGER_GESTURE
                    markAttendanceOnBackend(displayEmployeeName, ATTENDANCE_TRIGGER_GESTURE, userLatitude, userLongitude);
                }, error => {
                    console.warn("Geolocation error:", error);
                    updateStatusMessage('warning', "Couldn't get your location. Marking attendance without location check.");
                    // Changed "AutoMark" back to ATTENDANCE_TRIGGER_GESTURE
                    markAttendanceOnBackend(displayEmployeeName, ATTENDANCE_TRIGGER_GESTURE, null, null);
                }, {enableHighAccuracy: true, timeout: 5000, maximumAge: 0}); // Options for geolocation
            } else {
                const timeLeft = ATTENDANCE_COOLDOWN_SECONDS - Math.floor((currentTime - lastAttendanceMarkedTime) / 1000);
                console.log(`[INFO] Attendance cooldown active for ${displayEmployeeName}. Time left: ${timeLeft}s`);
                updateStatusMessage('info', `Attendance for ${displayEmployeeName} recently marked. Please wait.`);
            }
            // --- END AUTOMATIC ATTENDANCE MARKING ---

            // Original gesture check (commented out)
            // if (currentGesture === ATTENDANCE_TRIGGER_GESTURE) { ... }
            break;

        case SYSTEM_STATE.ATTENDANCE_PROCESSING:
            console.log("[STATE: ATTENDANCE_PROCESSING] Waiting for backend response.");
            updateStatusMessage('info', "Processing attendance, please wait...");
            break;

        case SYSTEM_STATE.INITIAL:
        default:
            updateStatusMessage('info', "System initializing. Please wait...");
            if (employeeIdDisplay) employeeIdDisplay.textContent = 'Waiting for scan...';
            console.log("[STATE: INITIAL] Awaiting webcam start/model load.");
            break;
    }

    if (webcamRunning === true) {
        window.requestAnimationFrame(predictWebcam);
    }
}

// Helper function to get face position from the current video frame using Face-API.js
async function getFacePositionFromCurrentFrame() {
    if (typeof window.faceapi === 'undefined' || !video || video.readyState < 2) {
        return {status: 'no_face', message: 'Video not ready or Face-API.js not loaded.'};
    }
    // Now detecting all faces to check for count
    const detections = await window.faceapi.detectAllFaces(video, new window.faceapi.TinyFaceDetectorOptions());
    if (detections.length === 1) {
        noFaceDetectedAttempts = 0;
        return checkFacePosition(detections[0].detection);
    } else if (detections.length > 1) {
        return {status: 'multiple_faces', message: 'Multiple faces detected.'};
    } else {
        return {status: 'no_face', message: 'No face detected.'};
    }
}


// --- Helper to capture a frame from video ---
function captureFrame(videoElement) {
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = videoElement.videoWidth;
    tempCanvas.height = videoElement.videoHeight;
    const tempCtx = tempCanvas.getContext('2d');
    tempCtx.translate(tempCanvas.width, 0);
    tempCtx.scale(-1, 1);
    tempCtx.drawImage(videoElement, 0, 0, tempCanvas.width, tempCanvas.height);
    const imageDataUrl = tempCanvas.toDataURL('image/jpeg', 0.8);
    console.log("🖼️ Frame captured for face recognition.");
    return imageDataUrl;
}

// --- Popup for "You are Late" ---
function showLatePopup(employeeName) {
    const popup = document.createElement('div');
    popup.className = 'popup popup--late';
    popup.textContent = `You are late, ${employeeName}!`;
    document.body.appendChild(popup);

    setTimeout(() => popup.remove(), 4000);
    console.log(`🔔 "You are Late" popup shown for ${employeeName}.`);
}

function showAttendanceSuccessPopup(message, employeeName) {
    const popup = document.createElement('div');
    popup.className = 'popup popup--success';
    popup.innerHTML = `✅ Attendance marked for <strong>${employeeName}</strong><br/>${message}`;
    document.body.appendChild(popup);

    setTimeout(() => popup.remove(), 4000);
    console.log(`🎉 "Attendance Marked" popup shown for ${employeeName}.`);

    // Trigger recent records update
    updateRecentRecords();
}

/**
 * Displays a popup prompting the user to press the camera button or space bar.
 */
function pressCameraButtonPopup() {
    // Remove any existing camera button popups to prevent duplicates
    const existingPopup = document.querySelector('.popup--camera');
    if (existingPopup) {
        existingPopup.remove();
    }

    const popup = document.createElement('div');
    popup.className = 'popup popup--camera';
    popup.textContent = 'Press the camera button or space bar to scan your face.';
    document.body.appendChild(popup);

    // Automatically remove the popup after a few seconds
    setTimeout(() => {
        if (popup.parentNode) { // Check if it's still in the DOM
            popup.remove();
        }
    }, 4000); // Popup disappears after 4 seconds
    console.log('📸 "Press Camera Button" popup shown.');
}

/**
 * Displays a popup when a face is recognized, prompting for a gesture.
 * @param {string} employeeName - The name of the recognized employee.
 */
function recognizedFacePopup(employeeName) {
    // Remove any existing recognized face popups
    const existingPopup = document.querySelector('.popup--recognized-face');
    if (existingPopup) {
        existingPopup.remove();
    }

    const popup = document.createElement('div');
    popup.className = 'popup popup--recognized-face';
    popup.innerHTML = `👋 Welcome, <strong>${employeeName}</strong>! Marking attendance automatically.`; // Updated message
    document.body.appendChild(popup);

    // Automatically remove the popup after a few seconds
    setTimeout(() => {
        if (popup.parentNode) { // Check if it's still in the DOM
            popup.remove();
        }
    }, 5000); // Popup disappears after 5 seconds
    console.log(`👤 "Recognized Face" popup shown for ${employeeName}.`);
}


// Function to refresh recent attendance records
function updateRecentRecords() {
    // Make an AJAX call to fetch recent attendance records
    fetch('/attendance/recent-attendance-records/')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update the HTML for recent records if successful
                recentRecordsScrollContainer.innerHTML = data.records_html; // Use the correct container
                if (data.records_html.trim() !== '') {
                    noRecentRecordsMessage.style.display = 'none';
                } else {
                    noRecentRecordsMessage.style.display = 'block';
                }
                const scrollArrows = document.querySelector('.scroll-arrows');
                if (recentRecordsScrollContainer.scrollWidth > recentRecordsScrollContainer.clientWidth) {
                    if (scrollArrows) scrollArrows.style.display = 'flex';
                } else {
                    if (scrollArrows) scrollArrows.style.display = 'none';
                }
                console.log("✅ Recent records updated successfully.");
            } else {
                console.error("⚠️ Failed to update recent records:", data.message);
            }
        })
        .catch(error => {
            console.error("❌ Error updating recent attendance records:", error);
            if (recentRecordsScrollContainer) {
                recentRecordsScrollContainer.innerHTML = '<div class="no-recent-records text-red-500">Failed to load records. Check connection.</div>';
            }
            if (noRecentRecordsMessage) {
                noRecentRecordsMessage.style.display = 'none';
            }
        });
}


// --- Backend Communication Functions ---

async function recognizeFaceOnBackend(imageDataUrl) {
    console.log(`📡 Sending image to backend for face recognition.`);
    updateStatusMessage('info', "Scanning for face...");
    if (employeeIdDisplay) employeeIdDisplay.textContent = "Recognizing...";

    try {
        const response = await fetch('/attendance/recognize-face-for-prompt/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken')
            },
            body: JSON.stringify({
                image: imageDataUrl
            })
        });

        const data = await response.json();
        console.log("✅ Face Recognition Response from Backend:", data);

        if (response.ok) {
            if (data.status === 'success' && data.recognized_name !== 'Unknown') {
                recognizedEmployeeName = data.recognized_name;
                setSystemState(SYSTEM_STATE.FACE_RECOGNIZED_PROMPT_GESTURE);
                console.log(`🥳 Face recognized: ${recognizedEmployeeName}. Ready for automatic attendance.`); // Updated log
            } else {
                recognizedEmployeeName = null;
                employeeIdDisplay.textContent = 'Unknown Face';
                updateStatusMessage('warning', data.message || 'No recognizable face detected. Press Spacebar or Camera button to re-scan.');
                setSystemState(SYSTEM_STATE.FACE_RECOGNIZING);
                recognizedPopupShown = false;
                isScanningAllowed = false;
                console.log(`⚠️ Face recognition: ${data.message || 'Unknown face detected'}. Paused scanning.`);
            }
        } else {
            recognizedEmployeeName = null;
            employeeIdDisplay.textContent = 'Error';
            updateStatusMessage('error', `Error during recognition. Please try again or contact support.`);
            setSystemState(SYSTEM_STATE.FACE_RECOGNIZING);
            recognizedPopupShown = false;
            isScanningAllowed = false;
            console.error(`❌ Server error (${response.status}) during face recognition: ${data.message}`);
        }
    } catch (error) {
        console.error("❌ Network error during face recognition:", error);
        recognizedEmployeeName = null;
        employeeIdDisplay.textContent = 'Network Error';
        updateStatusMessage('error', "Network error. Please check your internet connection.");
        setSystemState(SYSTEM_STATE.FACE_RECOGNIZING);
        recognizedPopupShown = false;
        isScanningAllowed = false;
    }
}

async function markAttendanceOnBackend(name, gesture, latitude, longitude) {
    console.log(`📡 Sending attendance request for ${name} with gesture ${gesture}. Current Emotion: ${currentEmotion}. Lat: ${latitude}, Lng: ${longitude}`);
    updateStatusMessage('info', `Marking attendance for ${name}...`);
    if (employeeIdDisplay) employeeIdDisplay.textContent = "Marking...";

    try {
        const response = await fetch('/attendance/mark-attendance-with-gesture/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken')
            },
            body: JSON.stringify({
                recognized_name: name,
                gesture: gesture,
                emotional_state: currentEmotion,
                latitude: latitude,
                longitude: longitude
            })
        });

        const data = await response.json();
        console.log("✅ Attendance Marking Response from Backend:", data);

        if (response.ok) {
            // SUCCESS path
            updateStatusMessage('success', data.message);
            speak(data.message);

            if (data.is_late) {
                showLatePopup(name);
            } else {
                showAttendanceSuccessPopup(data.message, name);
            }

            lastAttendanceMarkedTime = Date.now();
            updateRecentRecords();

        } else if (data.status === 'info') {
            // BUSINESS‑LOGIC INFO path (e.g., already marked)
            updateStatusMessage('info', data.message);
            speak(data.message);
            console.log(`ℹ️ Attendance info: ${data.message}`);

        } else {
            // FAILURE path
            updateStatusMessage('error', data.message || 'Failed to mark attendance. Please try again.');
            speak(data.message || 'Failed to mark attendance.');
            console.warn(`⚠️ Attendance warning/failure: ${data.message}`);
        }

    } catch (error) {
        // NETWORK or unexpected errors
        console.error("❌ Network error during attendance marking:", error);
        updateStatusMessage('error', "Network error. Unable to connect to server.");

    } finally {
        // ALWAYS reset scanner state
        setSystemState(SYSTEM_STATE.FACE_RECOGNIZING);
        recognizedPopupShown = false;
        recognizedEmployeeName = null;
        currentEmotion = null;
        isScanningAllowed = false;
        console.log("🔄 Reverting to FACE_RECOGNIZING state after attendance attempt. Scanning paused.");

        setTimeout(() => {
            if (currentSystemState === SYSTEM_STATE.FACE_RECOGNIZING) {
                if (employeeIdDisplay) employeeIdDisplay.textContent = 'Press Spacebar or Camera button to scan.';
                updateStatusMessage('info', "Scan complete. Press Spacebar or Camera button for next scan.");
                console.log("⏱️ Display reverted to scanning message.");
                pressCameraButtonPopup(); // Show the prompt again after a short delay
            }
        }, 3000);
    }
}


// Helper function to get CSRF token for Django POST requests
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    console.log(`🍪 CSRF Token: ${cookieValue ? 'Found' : 'Not Found'}`);
    return cookieValue;
}

/**
 * Updates the current date and time displayed in the header.
 */
function updateCurrentDateTime() {
    const now = new Date();
    const optionsDate = {weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'};
    const optionsTime = {hour: 'numeric', minute: 'numeric', hour12: true};
    const dateString = now.toLocaleDateString('en-US', optionsDate);
    const timeString = now.toLocaleTimeString('en-US', optionsTime);
    if (currentDateTimeElement) {
        currentDateTimeElement.textContent = `${dateString} | ${timeString}`;
    }
}

// Event listener for spacebar key press
document.addEventListener('keydown', (event) => {
    if (event.code === 'Space') {
        event.preventDefault();
        console.log("Spacebar pressed. isScanningAllowed set to true.");
        // Reset face recognition state variables
        recognizedEmployeeName = null;
        currentEmotion = null;
        recognizedPopupShown = false; // Reset popup shown flag

        if (currentSystemState === SYSTEM_STATE.FACE_RECOGNIZING ||
            currentSystemState === SYSTEM_STATE.FACE_RECOGNIZED_PROMPT_GESTURE ||
            currentSystemState === SYSTEM_STATE.MULTIPLE_FACES_DETECTED) { // Allow reset from all these states
            isScanningAllowed = true;
            noFaceDetectedAttempts = 0;
            updateStatusMessage('info', 'Scanning for face...');
            employeeIdDisplay.textContent = 'Scanning...';
            lastFaceRecognitionTime = 0; // Reset cooldown to allow immediate scan
            setSystemState(SYSTEM_STATE.FACE_RECOGNIZING); // Ensure we are in recognizing state
        } else if (currentSystemState === SYSTEM_STATE.ATTENDANCE_PROCESSING) {
            console.log("Spacebar pressed while processing attendance, ignoring.");
        }
    }
});

// Event listener for camera button click (new)
if (cameraButton) {
    cameraButton.addEventListener('click', () => {
        console.log("Camera button pressed. isScanningAllowed set to true.");
        // Reset face recognition state variables
        recognizedEmployeeName = null;
        currentEmotion = null;
        recognizedPopupShown = false; // Reset popup shown flag

        if (currentSystemState === SYSTEM_STATE.FACE_RECOGNIZING ||
            currentSystemState === SYSTEM_STATE.FACE_RECOGNIZED_PROMPT_GESTURE ||
            currentSystemState === SYSTEM_STATE.MULTIPLE_FACES_DETECTED) { // Allow reset from all these states
            isScanningAllowed = true;
            noFaceDetectedAttempts = 0;
            updateStatusMessage('info', 'Scanning for face...');
            employeeIdDisplay.textContent = 'Scanning...';
            lastFaceRecognitionTime = 0; // Reset cooldown to allow immediate scan
            setSystemState(SYSTEM_STATE.FACE_RECOGNIZING); // Ensure we are in recognizing state
        } else if (currentSystemState === SYSTEM_STATE.ATTENDANCE_PROCESSING) {
            console.log("Camera button pressed while processing attendance, ignoring.");
        }
    });
}


// Global initialization on window load
window.onload = async () => {
    console.log("🚀 Window loaded. Initializing application...");
    await loadFaceApiModels();
    await createGestureRecognizer();

    updateCurrentDateTime();
    setInterval(updateCurrentDateTime, 1000);

    updateRecentRecords();
    pressCameraButtonPopup(); // Initial call to show prompt
};

window.onbeforeunload = () => {
    console.log("👋 Window is about to unload. Stopping webcam and speech.");
    if (video && video.srcObject) {
        video.srcObject.getTracks().forEach(track => track.stop());
        console.log("📸 Webcam tracks stopped.");
    }
    if ('speechSynthesis' in window) {
        speechSynthesis.cancel();
        console.log("🗣️ Speech synthesis cancelled.");
    }
};
