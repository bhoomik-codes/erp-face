# attendance_app/admin.py
from django.contrib import admin
from .models import Employee, AttendanceRecord, LocationSetting, LeaveHistory, CustomUser

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('name', 'employee_id', 'role', 'last_seen')
    list_filter = ('role',)
    search_fields = ('name', 'employee_id')
    filter_horizontal = ('team_members',) # This provides a nice interface for ManyToMany fields

    fieldsets = (
        (None, {
            'fields': ('name', 'employee_id', 'photo', 'face_encoding', 'role')
        }),
        ('Team Leader Specific', {
            'fields': ('team_members',),
            'classes': ('collapse',), # Makes this section collapsible in the admin
            'description': 'Select team members if the role is Team Leader.'
        }),
        ('Timestamps', {
            'fields': ('last_seen', 'created_at', 'updated_at'),
            'classes': ('collapse',),
        }),
    )

    def get_fieldsets(self, request, obj=None):
        if obj and obj.role != 'TEAM_LEADER':
            # If not a Team Leader, hide the Team Leader specific fieldset
            return [
                (None, {
                    'fields': ('name', 'employee_id', 'photo', 'face_encoding', 'role')
                }),
                ('Timestamps', {
                    'fields': ('last_seen', 'created_at', 'updated_at'),
                    'classes': ('collapse',),
                }),
            ]
        return super().get_fieldsets(request, obj)


@admin.register(AttendanceRecord)
class AttendanceRecordAdmin(admin.ModelAdmin):
    list_display = ('employee', 'date', 'time', 'attendance_type', 'emotional_state')
    list_filter = ('date', 'attendance_type', 'employee')
    search_fields = ('employee__name', 'employee__employee_id')

@admin.register(LocationSetting)
class LocationSettingAdmin(admin.ModelAdmin):
    list_display = ('latitude', 'longitude', 'radius_meters', 'updated_at')

@admin.register(LeaveHistory)
class LeaveHistoryAdmin(admin.ModelAdmin):
    list_display = ('employee', 'month', 'leaves_taken')
    list_filter = ('month', 'employee')
    search_fields = ('employee__name',)

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    pass # Or customize as needed
