// Ensure jQuery is loaded before this script
$(document).ready(function () {
    // Initialize Select2 for the employee dropdown with full previous functionality
    $('.employee-select').select2({
        placeholder: "Search and select employees",
        allowClear: true,
        width: '100%',
        theme: 'default',
        matcher: function (params, data) {
            if ($.trim(params.term) === '') {
                return data;
            }
            if (typeof data.text === 'undefined') {
                return null;
            }
            const searchTerm = params.term.toLowerCase();
            const text = data.text.toLowerCase();
            const id = $(data.element).val().toLowerCase();

            if (text.includes(searchTerm) || id.includes(searchTerm)) {
                return data;
            }
            return null;
        }
    });

    /**
     * Function to fetch and update the attendance table body using AJAX.
     */
    async function updateAttendanceTable() {
        console.log("🔄 Fetching updated attendance table HTML from backend...");
        const tableBody = document.getElementById('attendanceTableBody');
        const loadingOverlay = document.getElementById('attendanceTableLoadingOverlay'); // Assuming you'll add this HTML
        const messagesDiv = document.getElementById('messages'); // Assuming message div exists

        if (!tableBody) {
            console.error("Error: tbody element with ID 'attendanceTableBody' not found.");
            return;
        }

        // Show loading indicator
        if (loadingOverlay) {
            loadingOverlay.style.display = 'flex'; // Show loading overlay
        } else {
            // Fallback: dim the table or show a simple text message
            tableBody.classList.add('opacity-50', 'pointer-events-none');
            // Optionally, tableBody.innerHTML = '<tr><td colspan="11" class="text-center py-4">Loading...</td></tr>';
        }


        const form = document.getElementById('attendanceFilterForm');
        const formData = new FormData(form);
        const params = new URLSearchParams();

        for (const [key, value] of formData.entries()) {
            params.append(key, value);
        }

        const url = `/attendance/get-attendance-table/?${params.toString()}`;

        try {
            const response = await fetch(url);
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
            }
            const data = await response.json();

            if (data.html) {
                $('#attendanceTableBody').html(data.html);
                console.log("✅ Attendance table updated successfully.");
            } else {
                console.warn("Received empty HTML from backend for attendance table.");
                // Updated colspan to 11 for the "No records found" message
                $('#attendanceTableBody').html('<tr><td colspan="11" class="px-6 py-4 text-center text-gray-500">No records found.</td></tr>');
            }
        } catch (error) {
            console.error('❌ Error fetching updated attendance table:', error);
            // Updated colspan to 11 for the error message
            $('#attendanceTableBody').html('<tr><td colspan="11" class="px-6 py-4 text-center text-red-500">Failed to load attendance data. Please try again.</td></tr>');
            if (messagesDiv && typeof window.displayMessage === 'function') {
                window.displayMessage(messagesDiv, "Failed to load attendance records. Please try again.", 'error');
            } else {
                console.warn('displayMessage function not found or messages div not present. Cannot show user-friendly error message.');
            }
        } finally {
            // Hide loading indicator
            if (loadingOverlay) {
                loadingOverlay.style.display = 'none'; // Hide loading overlay
            } else {
                tableBody.classList.remove('opacity-50', 'pointer-events-none');
            }
        }
    }

    // Attach event listener to the form's submit event
    $('#attendanceFilterForm').on('submit', function (e) {
        e.preventDefault();
        updateAttendanceTable();
    });

    /**
     * Global function to clear all filter fields and refresh the table.
     */
    window.clearFilters = function () {
        $('#start_date').val('');
        $('#end_date').val('');
        $('.employee-select').val(null).trigger('change');
        $('#attendance_type').val(''); // This field is commented out in HTML, but kept here for robustness
        $('#total_hours_lt').val('');
        updateAttendanceTable();
    };

    /**
     * Function to trigger attendance report download.
     * @param {string} format - The desired export format ('csv', 'xlsx', 'pdf').
     */
    function downloadReport(format) {
        const form = document.getElementById('attendanceFilterForm');
        const formData = new FormData(form);
        const params = new URLSearchParams();

        for (const [key, value] of formData.entries()) {
            params.append(key, value);
        }

        let url = '';
        if (format === 'csv') {
            url = `/attendance/export-attendance-csv/?${params.toString()}`;
        } else if (format === 'xlsx') {
            url = `/attendance/export-attendance-xlsx/?${params.toString()}`;
        } else if (format === 'pdf') {
            url = `/attendance/export-attendance-pdf/?${params.toString()}`;
        } else {
            console.error('Invalid export format:', format);
            return;
        }

        window.open(url, '_blank'); // Open in new tab to trigger download
    }

    // Attach click listeners to export buttons
    $('#exportCsv').on('click', function () {
        downloadReport('csv');
    });

    $('#exportXlsx').on('click', function () {
        downloadReport('xlsx');
    });

    $('#exportPdf').on('click', function () {
        downloadReport('pdf');
    });


    // Initial call to populate the table on page load.
    updateAttendanceTable();

    // Set intervals to periodically update the entire attendance table
    // Reconsidering the interval: 30 seconds can be frequent for full table updates.
    // Adjust based on your server load and how "real-time" the report needs to be.
    // For a report, 1-5 minutes might be more appropriate, or rely solely on manual refresh.
    // Keeping it at 30s as per original, but noting consideration.
    setInterval(updateAttendanceTable, 30000);
});
