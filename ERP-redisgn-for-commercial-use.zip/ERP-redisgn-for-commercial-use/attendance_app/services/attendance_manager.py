# attendance_app/services/attendance_manager.py
import random
from datetime import datetime, time, timedelta, date
from collections import defaultdict
import calendar  # Import calendar for month-end calculation

import cv2
import numpy as np
from django.conf import settings
from django.db.models import Max, Q, Count, Sum
from django.utils import timezone
from geopy.distance import geodesic

# Relative imports for models and face_recognizer
from ..models import AttendanceRecord, Employee, LocationSetting, LeaveHistory
from ..face_recognizer import FaceRecognitionSystem

# Initialize face recognition system globally here if it's a singleton
_face_recognition_system_instance = None


def get_face_recognition_system():
    global _face_recognition_system_instance
    if _face_recognition_system_instance is None:
        _face_recognition_system_instance = FaceRecognitionSystem(tolerance=0.6)
    return _face_recognition_system_instance


# Initialize face recognition system on startup (moved here from original views.py)
get_face_recognition_system()


class AttendanceManager:
    # Time windows for different attendance types
    IN_TIME_START = time(10, 0)  # 10:00 AM
    IN_TIME_END = time(11, 0)  # 11:00 AM
    LUNCH_TIME_START = time(13, 30)  # 1:30 PM
    LUNCH_TIME_END = time(14, 30)  # 2:30 PM
    MAX_LUNCH_DURATION = timedelta(hours=1, minutes=30)
    OUT_TIME_MIN = time(19, 0)  # 7:00 PM
    OFFICE_CLOSE = time(23, 59)  # 11:00 PM for auto-checkout
    STANDARD_WORK_HOURS = 9

    @staticmethod
    def auto_checkout_employees():
        today = date.today()
        employees_in_today = Employee.objects.filter(
            attendance_records__date=today,
            attendance_records__attendance_type='IN'
        ).distinct()

        for employee in employees_in_today:
            has_checked_out = AttendanceRecord.objects.filter(
                employee=employee,
                date=today,
                attendance_type='OUT'
            ).exists()

            if not has_checked_out:
                AttendanceManager.create_attendance_record(
                    employee=employee,
                    attendance_type='OUT',
                    remarks=f"Auto-checked out at {AttendanceManager.OFFICE_CLOSE.strftime('%H:%M')} (Overtime not counted)"
                )
                print(f"Auto-checked out employee: {employee.name}")

    @staticmethod
    def determine_attendance_type(employee):
        current_time = datetime.now().time()
        today = datetime.now().date()

        today_records = AttendanceRecord.objects.filter(employee=employee, date=today).order_by('time')
        last_record = today_records.last()

        if not last_record:
            remark = ""
            is_late = False
            if current_time > AttendanceManager.IN_TIME_END:
                remark = "Late entry."
                is_late = True
            elif current_time < AttendanceManager.IN_TIME_START:
                remark = "Early entry."
            return 'IN', f"{employee.name}: In Time. {remark}", is_late

        current_state = last_record.attendance_type

        msg_already_in = f"{employee.name}: Already Checked In."
        msg_already_out = f"{employee.name}: Already Checked Out."
        msg_already_on_lunch = f"{employee.name}: Already on Lunch. Expected Lunch Out."
        msg_already_on_break = f"{employee.name}: Already on a Break. Expected Break Out."
        msg_returning_from_lunch = f"{employee.name}: Returning from Lunch. Still active."
        msg_returning_from_break = f"{employee.name}: Returning from Break. Still active."

        if current_state == 'IN':
            last_lunch_record = today_records.filter(
                Q(attendance_type='LUNCH_IN') | Q(attendance_type='LUNCH_OUT')).last()
            if current_time >= AttendanceManager.LUNCH_TIME_START and current_time <= AttendanceManager.LUNCH_TIME_END:
                if not last_lunch_record or last_lunch_record.attendance_type == 'LUNCH_OUT':
                    return 'LUNCH_IN', f"{employee.name}: Lunch In", False
                else:
                    return None, msg_already_on_lunch, False

            last_break_record = today_records.filter(
                Q(attendance_type='BREAK_IN') | Q(attendance_type='BREAK_OUT')).last()
            if not last_break_record or last_break_record.attendance_type == 'BREAK_OUT':
                return 'BREAK_IN', f"{employee.name}: Break In", False
            else:
                return None, msg_already_on_break, False

        elif current_state == 'LUNCH_IN':
            if current_time > AttendanceManager.LUNCH_TIME_END:
                return 'LUNCH_OUT', f"{employee.name}: Auto Lunch Out (past {AttendanceManager.LUNCH_TIME_END.strftime('%H:%M')}).", False
            return 'LUNCH_OUT', f"{employee.name}: Lunch Out", False

        elif current_state == 'LUNCH_OUT':
            if current_time > AttendanceManager.OUT_TIME_MIN:
                if not today_records.filter(attendance_type='OUT').exists():
                    return 'OUT', f"{employee.name}: Out Time", False
                else:
                    return None, msg_already_out, False
            else:
                return None, msg_returning_from_lunch, False

        elif current_state == 'BREAK_IN':
            return 'BREAK_OUT', f"{employee.name}: Break Out", False

        elif current_state == 'BREAK_OUT':
            if current_time > AttendanceManager.OUT_TIME_MIN:
                if not today_records.filter(attendance_type='OUT').exists():
                    return 'OUT', f"{employee.name}: Out Time", False
                else:
                    return None, msg_already_out, False
            else:
                return None, msg_returning_from_break, False

        elif current_state == 'OUT':
            return 'IN', f"{employee.name}: Starting new session (After daily OUT).", False

        return None, "No specific attendance action needed based on current state and time.", False

    @staticmethod
    def create_attendance_record(employee, attendance_type, remarks="", emotional_state=None):
        """Creates a new attendance record for the employee."""
        record_kwargs = {
            'employee': employee,
            'date': date.today(),
            'time': datetime.now().time(),
            'attendance_type': attendance_type,
            'remarks': remarks
        }
        if attendance_type == 'IN' and emotional_state:
            record_kwargs['emotional_state'] = emotional_state
        AttendanceRecord.objects.create(**record_kwargs)
        employee.last_seen = timezone.now()
        employee.save()
        print(f"Attendance recorded for {employee.name} as {attendance_type}")
        # Log emotional state to console only if it's an IN entry and was provided
        if emotional_state and attendance_type == 'IN':
            print(f"Emotional state recorded: {emotional_state}")

    @staticmethod
    def calculate_working_hours(employee, target_date):
        """
        Calculates total working hours, lunch duration, and break duration for an employee on a given date.
        It considers 'IN' and 'OUT' pairs, as well as 'LUNCH_IN'/'LUNCH_OUT' and 'BREAK_IN'/'BREAK_OUT' pairs.
        For the current date, if an 'IN' record exists without a corresponding 'OUT',
        it calculates hours up to the current time.
        """
        records = AttendanceRecord.objects.filter(employee=employee, date=target_date).order_by('time')

        total_working_seconds = 0
        lunch_duration_seconds = 0
        break_duration_seconds = 0

        current_in_time = None
        current_lunch_in_time = None
        current_break_in_time = None

        has_out = False  # Flag to indicate if an OUT record exists for the day

        for record in records:
            if record.attendance_type == 'IN':
                current_in_time = record.time
            elif record.attendance_type == 'OUT':
                if current_in_time:  # Only calculate if there was a preceding IN
                    duration = datetime.combine(target_date, record.time) - datetime.combine(target_date,
                                                                                             current_in_time)
                    total_working_seconds += duration.total_seconds()
                    current_in_time = None  # Reset for next IN/OUT pair
                has_out = True  # An OUT record was found

            elif record.attendance_type == 'LUNCH_IN':
                current_lunch_in_time = record.time
            elif record.attendance_type == 'LUNCH_OUT':
                if current_lunch_in_time:  # Only calculate if there was a preceding LUNCH_IN
                    duration = datetime.combine(target_date, record.time) - datetime.combine(target_date,
                                                                                             current_lunch_in_time)
                    lunch_duration_seconds += duration.total_seconds()
                    current_lunch_in_time = None  # Reset
            elif record.attendance_type == 'BREAK_IN':
                current_break_in_time = record.time
            elif record.attendance_type == 'BREAK_OUT':
                if current_break_in_time:  # Only calculate if there was a preceding BREAK_IN
                    duration = datetime.combine(target_date, record.time) - datetime.combine(target_date,
                                                                                             current_break_in_time)
                    break_duration_seconds += duration.total_seconds()
                    current_break_in_time = None  # Reset

        # Handle ongoing IN sessions for the current day
        if target_date == date.today() and current_in_time and not has_out:
            # Calculate time from the last IN until now
            duration = datetime.now() - datetime.combine(target_date, current_in_time)
            total_working_seconds += duration.total_seconds()
            # If there's an active LUNCH_IN or BREAK_IN, subtract time from it
            if current_lunch_in_time:
                lunch_active_duration = datetime.now() - datetime.combine(target_date, current_lunch_in_time)
                lunch_duration_seconds += lunch_active_duration.total_seconds()
            if current_break_in_time:
                break_active_duration = datetime.now() - datetime.combine(target_date, current_break_in_time)
                break_duration_seconds += break_active_duration.total_seconds()

        # Adjust total working hours by subtracting lunch and break times
        net_working_seconds = total_working_seconds - lunch_duration_seconds - break_duration_seconds

        # Ensure net working seconds is not negative
        if net_working_seconds < 0:
            net_working_seconds = 0

        total_working_hours = round(net_working_seconds / 3600, 2)
        lunch_duration_hours = round(lunch_duration_seconds / 3600, 2)
        break_duration_hours = round(break_duration_seconds / 3600, 2)

        return total_working_hours, lunch_duration_hours, break_duration_hours, has_out

    @staticmethod
    def get_filtered_attendance_summary(filter_start_date_str, filter_end_date_str,
                                        filter_employee_ids_list, filter_attendance_type,
                                        filter_total_hours_lt):
        """
        Helper method to encapsulate the logic for filtering and preparing
        attendance records for display in the report.
        """
        print(f"DEBUG: Entering get_filtered_attendance_summary with filters:")
        print(f"  start_date_str: {filter_start_date_str}")
        print(f"  end_date_str: {filter_end_date_str}")
        print(f"  employee_ids_list: {filter_employee_ids_list}")
        print(f"  attendance_type: {filter_attendance_type}")
        print(f"  total_hours_lt: {filter_total_hours_lt}")
        filter_start_date_obj = None
        if filter_start_date_str:
            try:
                filter_start_date_obj = datetime.strptime(filter_start_date_str, '%Y-%m-%d').date()
            except ValueError:
                print(f"DEBUG: ValueError parsing start_date: {filter_start_date_str}")
                pass
        filter_end_date_obj = None
        if filter_end_date_str:
            try:
                filter_end_date_obj = datetime.strptime(filter_end_date_str, '%Y-%m-%d').date()
            except ValueError:
                print(f"DEBUG: ValueError parsing end_date: {filter_end_date_str}")
                pass
        print(f"DEBUG: Parsed dates: start_date_obj={filter_start_date_obj}, end_date_obj={filter_end_date_obj}")
        records_queryset = AttendanceRecord.objects.filter(employee__isnull=False)
        print(f"DEBUG: Initial records_queryset count (filtered for valid employee FK): {records_queryset.count()}")

        if filter_start_date_obj:
            records_queryset = records_queryset.filter(date__gte=filter_start_date_obj)
            print(f"DEBUG: After start_date filter, count: {records_queryset.count()}")
        if filter_end_date_obj:
            records_queryset = records_queryset.filter(date__lte=filter_end_date_obj)
            print(f"DEBUG: After end_date filter, count: {records_queryset.count()}")

        if filter_employee_ids_list:
            records_queryset = records_queryset.filter(
                employee__employee_id__in=[str(id).strip() for id in filter_employee_ids_list])
            print(f"DEBUG: After employee_ids filter ({filter_employee_ids_list}), count: {records_queryset.count()}")

        if filter_attendance_type:
            records_queryset = records_queryset.filter(attendance_type=filter_attendance_type)
            print(f"DEBUG: After attendance_type filter ({filter_attendance_type}), count: {records_queryset.count()}")

        relevant_employee_dates = records_queryset.values('employee__employee_id', 'date').distinct().order_by(
            'employee__employee_id', 'date')
        print(f"DEBUG: Distinct employee_dates found (from filtered queryset): {list(relevant_employee_dates)}")

        attendance_summary = []
        for item in relevant_employee_dates:
            employee_id_from_item = item['employee__employee_id']
            report_date = item['date']

            print(
                f"DEBUG: Attempting to look up Employee with employee_id: '{employee_id_from_item}' (Type: {type(employee_id_from_item)})")

            all_existing_employee_ids = list(Employee.objects.all().values_list('employee_id', flat=True))
            print(f"DEBUG: All Employee.employee_ids in DB: {all_existing_employee_ids}")

            try:
                employee = Employee.objects.get(employee_id=employee_id_from_item)
                print(f"DEBUG: Successfully found Employee: {employee.name} (ID: {employee.employee_id})")
            except Employee.DoesNotExist:
                print(
                    f"DEBUG: CRITICAL ERROR: Employee with employee_id '{employee_id_from_item}' not found during final lookup for date {report_date}. This indicates a data integrity issue.")
                continue
            except Exception as e:
                print(f"DEBUG: UNEXPECTED ERROR during Employee lookup for ID '{employee_id_from_item}': {e}")
                continue

            total_hours, lunch_time_total, break_time_total, has_out = AttendanceManager.calculate_working_hours(
                employee, report_date)
            print(
                f"DEBUG: Calculated hours for {employee.name} (ID: {employee.employee_id}) on {report_date}: {total_hours} hours, Has Out: {has_out}")

            if filter_total_hours_lt:
                try:
                    target_hours_lt = float(filter_total_hours_lt)
                    if total_hours >= target_hours_lt:
                        print(f"DEBUG: Skipping {employee.name} on {report_date} as {total_hours} >= {target_hours_lt}")
                        continue
                except ValueError:
                    print(f"DEBUG: ValueError parsing total_hours_lt: {filter_total_hours_lt}")
                    pass

            in_record = AttendanceRecord.objects.filter(employee=employee, date=report_date,
                                                        attendance_type='IN').first()
            out_record = AttendanceRecord.objects.filter(employee=employee, date=report_date,
                                                         attendance_type='OUT').first()
            lunch_in_record = AttendanceRecord.objects.filter(employee=employee, date=report_date,
                                                              attendance_type='LUNCH_IN').first()
            lunch_out_record = AttendanceRecord.objects.filter(employee=employee, date=report_date,
                                                               attendance_type='LUNCH_OUT').first()
            break_in_record = AttendanceRecord.objects.filter(employee=employee, date=report_date,
                                                              attendance_type='BREAK_IN').first()
            break_out_record = AttendanceRecord.objects.filter(employee=employee, date=report_date,
                                                               attendance_type='BREAK_OUT').first()

            remarks_list = [r.remarks for r in
                            AttendanceRecord.objects.filter(employee=employee, date=report_date).exclude(
                                remarks__isnull=True).exclude(remarks__exact='')]
            combined_remarks = "; ".join(remarks_list) if remarks_list else None

            is_late_for_record = False
            if in_record and in_record.time and in_record.time > AttendanceManager.IN_TIME_END:
                is_late_for_record = True

            attendance_summary.append({
                'employee_name': employee.name,
                'employee_id': employee.employee_id,
                'photo_url': employee.photo.url if employee.photo else settings.STATIC_URL + 'img/default_avatar.png',
                # Use settings.STATIC_URL
                'date': report_date.strftime('%Y-%m-%d'),
                'in_time': in_record.time.strftime('%I:%M %p') if in_record and in_record.time else None,
                'out_time': out_record.time.strftime('%I:%M %p') if out_record and out_record.time else None,
                'lunch_in_time': lunch_in_record.time.strftime(
                    '%I:%M %p') if lunch_in_record and lunch_in_record.time else None,
                'lunch_out_time': lunch_out_record.time.strftime(
                    '%I:%M %p') if lunch_in_record and lunch_out_record.time else None,
                'break_in_time': break_in_record.time.strftime(
                    '%I:%M %p') if break_in_record and break_in_record.time else None,
                'break_out_time': break_out_record.time.strftime(
                    '%I:%M %p') if break_in_record and break_out_record.time else None,
                'total_working_hours': f"{total_hours} hours" if has_out or (
                        report_date != date.today()) else 'In progress...',
                'remarks': combined_remarks,
                'is_late': is_late_for_record,
                'emotional_state': in_record.emotional_state if in_record else None,
            })

        print(f"DEBUG: Final attendance_summary count: {len(attendance_summary)}")
        print(f"DEBUG: Exiting get_filtered_attendance_summary.")

        attendance_summary.sort(key=lambda x: (x['date'], x['employee_name']))
        return attendance_summary

    @staticmethod
    def calculate_daily_summary(attendance_records):
        """
        Calculates daily summary (in_time, out_time, total_hours etc.) for a given queryset of attendance records.
        This version is more comprehensive to handle all IN/OUT/Lunch/Break pairs for accurate total hours calculation.
        """
        employee_daily_summary = {}

        for record in attendance_records:
            key = (record.employee.employee_id, record.date)  # Use employee_id for the key

            if key not in employee_daily_summary:
                employee_daily_summary[key] = {
                    'employee': record.employee,
                    'date': record.date,
                    'in_time': None,
                    'out_time': None,
                    'lunch_in_time': None,
                    'lunch_out_time': None,
                    'break_in_time': None,
                    'break_out_time': None,
                    'total_hours': 0,  # Placeholder, will be calculated by calculate_working_hours
                    'remark': ''  # Initialize remark
                }

            # Update times based on attendance type, taking earliest for IN/LUNCH_IN/BREAK_IN
            # and latest for OUT/LUNCH_OUT/BREAK_OUT for a given day
            if record.attendance_type == 'IN':
                if employee_daily_summary[key]['in_time'] is None or record.time < employee_daily_summary[key][
                    'in_time']:
                    employee_daily_summary[key]['in_time'] = record.time
            elif record.attendance_type == 'OUT':
                if employee_daily_summary[key]['out_time'] is None or record.time > employee_daily_summary[key][
                    'out_time']:
                    employee_daily_summary[key]['out_time'] = record.time
            elif record.attendance_type == 'LUNCH_IN':
                if employee_daily_summary[key]['lunch_in_time'] is None or record.time < employee_daily_summary[key][
                    'lunch_in_time']:
                    employee_daily_summary[key]['lunch_in_time'] = record.time
            elif record.attendance_type == 'LUNCH_OUT':
                if employee_daily_summary[key]['lunch_out_time'] is None or record.time > employee_daily_summary[key][
                    'lunch_out_time']:
                    employee_daily_summary[key]['lunch_out_time'] = record.time
            elif record.attendance_type == 'BREAK_IN':
                if employee_daily_summary[key]['break_in_time'] is None or record.time < employee_daily_summary[key][
                    'break_in_time']:
                    employee_daily_summary[key]['break_in_time'] = record.time
            elif record.attendance_type == 'BREAK_OUT':
                if employee_daily_summary[key]['break_out_time'] is None or record.time > employee_daily_summary[key][
                    'break_out_time']:
                    employee_daily_summary[key]['break_out_time'] = record.time

            # Use the latest remark for the day if available
            if record.remarks:
                employee_daily_summary[key]['remark'] = record.remarks

        final_summaries = []
        for key, data in employee_daily_summary.items():
            employee = data['employee']
            report_date = data['date']
            total_hours, lunch_duration, break_duration, has_out = AttendanceManager.calculate_working_hours(
                employee, report_date)

            # Construct total_duration_str and remark appropriately
            total_duration_str = f"{total_hours:.1f} hrs"
            remark_display = data['remark']
            if not has_out and report_date == timezone.localdate() and data['in_time']:
                remark_display = 'In progress...'  # Override remark if still in progress

            final_summaries.append({
                'employee': employee,
                'date': report_date,
                'in_time': data['in_time'],
                'out_time': data['out_time'],
                'lunch_in_time': data['lunch_in_time'],
                'lunch_out_time': data['lunch_out_time'],
                'break_in_time': data['break_in_time'],
                'break_out_time': data['break_out_time'],
                'total_hours': total_hours,
                'total_duration_str': total_duration_str if total_hours > 0 or has_out else remark_display,
                'remark': remark_display  # This remark is the one displayed
            })
        return final_summaries

    @staticmethod
    def get_present_employees_count(start_date, end_date):
        """
        Counts distinct employees who have an 'IN' attendance record within the given date range.
        """
        present_employees_daily = AttendanceRecord.objects.filter(
            date__range=[start_date, end_date],
            attendance_type='IN'
        ).values('employee', 'date').distinct()

        daily_counts = {}
        for entry in present_employees_daily:
            day = entry['date'].strftime('%Y-%m-%d')
            if day not in daily_counts:
                daily_counts[day] = set()
            daily_counts[day].add(entry['employee'])

        return {date_str: len(employee_set) for date_str, employee_set in daily_counts.items()}

    @staticmethod
    def get_attendance_trend_data(start_date, end_date, interval_type='daily'):
        """
        Generates attendance trend data (labels and counts of present employees)
        for various intervals (daily, monthly, yearly).
        This replaces the manual chart data generation in admin_views.py.
        """
        records = AttendanceRecord.objects.filter(
            date__range=[start_date, end_date],
            attendance_type='IN'
        ).order_by('date')

        labels = []
        current_data = []

        # Prepare for previous period data (for comparison in charts)
        prev_start_date = None
        prev_end_date = None
        if interval_type == 'daily':
            # For daily, previous period is previous week
            prev_start_date = start_date - timedelta(days=7)
            prev_end_date = end_date - timedelta(days=7)
        elif interval_type == 'monthly':
            # For monthly, previous period is previous year
            prev_start_date = start_date.replace(year=start_date.year - 1)
            prev_end_date = end_date.replace(year=end_date.year - 1)
        elif interval_type == 'yearly':
            # For yearly, previous period is previous year (for comparison)
            prev_start_date = start_date.replace(year=start_date.year - 1)
            prev_end_date = end_date.replace(year=end_date.year - 1)

        prev_records = AttendanceRecord.objects.filter(
            date__range=[prev_start_date, prev_end_date],
            attendance_type='IN'
        ).order_by('date') if prev_start_date and prev_end_date else AttendanceRecord.objects.none()

        current_period_counts = defaultdict(set)
        for record in records:
            if interval_type == 'daily':
                key = record.date.strftime('%Y-%m-%d')
            elif interval_type == 'monthly':
                key = record.date.strftime('%Y-%m')
            elif interval_type == 'yearly':
                key = str(record.date.year)
            current_period_counts[key].add(record.employee.id)

        prev_period_counts = defaultdict(set)
        for record in prev_records:
            if interval_type == 'daily':
                key = record.date.strftime('%Y-%m-%d')
            elif interval_type == 'monthly':
                key = record.date.strftime('%Y-%m')
            elif interval_type == 'yearly':
                key = str(record.date.year)
            prev_period_counts[key].add(record.employee.id)

        # Generate labels and data for the current period
        current_date_iter = start_date
        while current_date_iter <= end_date:
            if interval_type == 'daily':
                label = current_date_iter.strftime('%a %d')
                key = current_date_iter.strftime('%Y-%m-%d')
            elif interval_type == 'monthly':
                label = current_date_iter.strftime('%b %d')  # Day-wise within month
                key = current_date_iter.strftime('%Y-%m-%d')
            elif interval_type == 'yearly':
                label = current_date_iter.strftime('%b')  # Month-wise within year
                key = current_date_iter.strftime('%Y-%m')
                # For yearly trend, iterate by month
                current_date_iter = current_date_iter.replace(
                    day=1)  # Ensure we start from 1st of month for consistency
                if current_date_iter.month == 12:
                    next_date_iter = current_date_iter.replace(year=current_date_iter.year + 1, month=1, day=1)
                else:
                    next_date_iter = current_date_iter.replace(month=current_date_iter.month + 1, day=1)

            labels.append(label)
            current_data.append(len(current_period_counts.get(key, set())))

            if interval_type == 'daily' or interval_type == 'monthly':
                current_date_iter += timedelta(days=1)
            elif interval_type == 'yearly':
                current_date_iter = next_date_iter
                if current_date_iter > end_date:  # Stop if next month goes beyond end_date
                    break

        # Generate data for the previous period to match labels
        prev_data = []
        current_date_iter_for_prev = start_date
        while current_date_iter_for_prev <= end_date:
            if interval_type == 'daily':
                key = (current_date_iter_for_prev - timedelta(days=7)).strftime('%Y-%m-%d')
            elif interval_type == 'monthly':
                key = (current_date_iter_for_prev - timedelta(days=365)).strftime(
                    '%Y-%m-%d')  # Previous year, same day for monthly
            elif interval_type == 'yearly':
                key = (current_date_iter_for_prev.replace(year=current_date_iter_for_prev.year - 1)).strftime(
                    '%Y-%m')  # Previous year, same month for yearly
                # For yearly trend, iterate by month
                current_date_iter_for_prev = current_date_iter_for_prev.replace(day=1)
                if current_date_iter_for_prev.month == 12:
                    next_date_iter = current_date_iter_for_prev.replace(year=current_date_iter_for_prev.year + 1,
                                                                        month=1, day=1)
                else:
                    next_date_iter = current_date_iter_for_prev.replace(month=current_date_iter_for_prev.month + 1,
                                                                        day=1)

            prev_data.append(len(prev_period_counts.get(key, set())))

            if interval_type == 'daily' or interval_type == 'monthly':
                current_date_iter_for_prev += timedelta(days=1)
            elif interval_type == 'yearly':
                current_date_iter_for_prev = next_date_iter
                if current_date_iter_for_prev > end_date:
                    break

        # Pad data arrays if their lengths don't match (should be handled by iteration logic, but defensive)
        max_len = max(len(labels), len(current_data), len(prev_data))
        while len(labels) < max_len:
            labels.append("")
        while len(current_data) < max_len:
            current_data.append(0)
        while len(prev_data) < max_len:
            prev_data.append(0)

        return {
            'labels': labels,
            'current_data': current_data,
            'prev_data': prev_data,
        }

    @staticmethod
    def get_emotion_trends(start_date, end_date, interval_type='daily'):
        # Filters attendance records with emotional state for the given period.
        # Aggregates average sentiment per emotion for each interval.
        records = AttendanceRecord.objects.filter(
            date__range=[start_date, end_date],
            attendance_type='IN',
            emotional_state__isnull=False
        ).order_by('date')

        emotion_data = defaultdict(lambda: defaultdict(int))
        emotion_counts = defaultdict(lambda: defaultdict(int))
        labels = []

        if interval_type == 'daily':
            current_date = start_date
            while current_date <= end_date:
                label = current_date.strftime('%Y-%m-%d')
                labels.append(label)
                for record in records.filter(date=current_date):
                    emotion_data[label][record.emotional_state] += 1
                    emotion_counts[label]['total'] += 1
                current_date += timedelta(days=1)
        elif interval_type == 'weekly':
            # Group by week (Monday to Sunday)
            current_date = start_date
            while current_date <= end_date:
                week_start = current_date - timedelta(days=current_date.weekday())
                week_end = week_start + timedelta(days=6)
                label = f"{week_start.strftime('%Y-%m-%d')} to {week_end.strftime('%Y-%m-%d')}"
                if label not in labels:
                    labels.append(label)

                week_records = records.filter(date__range=[week_start, week_end])
                for record in week_records:
                    emotion_data[label][record.emotional_state] += 1
                    emotion_counts[label]['total'] += 1

                current_date = week_end + timedelta(days=1)  # Move to next week
        elif interval_type == 'monthly':
            # Group by month
            current_date = start_date
            while current_date <= end_date:
                month_start = current_date.replace(day=1)
                month_end_day = calendar.monthrange(current_date.year, current_date.month)[1]
                month_end = current_date.replace(day=month_end_day)

                label = month_start.strftime('%Y-%m')
                if label not in labels:
                    labels.append(label)

                month_records = records.filter(date__range=[month_start, month_end])
                for record in month_records:
                    emotion_data[label][record.emotional_state] += 1
                    emotion_counts[label]['total'] += 1

                if current_date.month == 12:
                    current_date = current_date.replace(year=current_date.year + 1, month=1, day=1)
                else:
                    current_date = current_date.replace(month=current_date.month + 1, day=1)
        elif interval_type == 'yearly':
            current_date = start_date
            while current_date <= end_date:
                year_start = date(current_date.year, 1, 1)
                year_end = date(current_date.year, 12, 31)

                label = str(current_date.year)
                if label not in labels:
                    labels.append(label)

                year_records = records.filter(date__range=[year_start, year_end])
                for record in year_records:
                    emotion_data[label][record.emotional_state] += 1
                    emotion_counts[label]['total'] += 1

                current_date = date(current_date.year + 1, 1, 1)

        # Calculate percentages
        emotions = ['happy', 'neutral', 'sad', 'angry', 'surprised', 'disgusted',
                    'fearful']  # Define expected emotions more broadly
        result = {emotion: [0] * len(labels) for emotion in emotions}

        for i, label in enumerate(labels):
            total = emotion_counts[label]['total']
            if total > 0:
                for emotion in emotions:
                    count = emotion_data[label][emotion]
                    result[emotion][i] = round((count / total) * 100, 2)

        return {
            'labels': labels,
            'happy': result['happy'],
            'neutral': result['neutral'],
            'sad': result['sad'],
            'angry': result['angry'],
            'surprised': result['surprised'],
            'disgusted': result['disgusted'],
            'fearful': result['fearful'],
        }

    @staticmethod
    def get_late_on_time_trends(start_date, end_date, interval_type='daily'):
        # Filters 'IN' attendance records for late/on-time status.
        # Aggregates percentages of late, on-time, and early arrivals for each interval.
        records = AttendanceRecord.objects.filter(
            date__range=[start_date, end_date],
            attendance_type='IN'
        ).order_by('date')

        arrival_counts = defaultdict(lambda: defaultdict(int))
        labels = []

        # Determine intervals and populate counts
        if interval_type == 'daily':
            current_date = start_date
            while current_date <= end_date:
                label = current_date.strftime('%Y-%m-%d')
                labels.append(label)
                day_records = records.filter(date=current_date)
                for record in day_records:
                    if record.time > AttendanceManager.IN_TIME_END:
                        arrival_counts[label]['late'] += 1
                    elif record.time < AttendanceManager.IN_TIME_START:
                        arrival_counts[label]['early'] += 1
                    else:
                        arrival_counts[label]['on_time'] += 1
                    arrival_counts[label]['total'] += 1
                current_date += timedelta(days=1)
        elif interval_type == 'weekly':
            current_date = start_date
            while current_date <= end_date:
                week_start = current_date - timedelta(days=current_date.weekday())
                week_end = week_start + timedelta(days=6)
                label = f"{week_start.strftime('%Y-%m-%d')} to {week_end.strftime('%Y-%m-%d')}"
                if label not in labels:
                    labels.append(label)

                week_records = records.filter(date__range=[week_start, week_end])
                for record in week_records:
                    if record.time > AttendanceManager.IN_TIME_END:
                        arrival_counts[label]['late'] += 1
                    elif record.time < AttendanceManager.IN_TIME_START:
                        arrival_counts[label]['early'] += 1
                    else:
                        arrival_counts[label]['on_time'] += 1
                    arrival_counts[label]['total'] += 1
                current_date = week_end + timedelta(days=1)
        elif interval_type == 'monthly':
            current_date = start_date
            while current_date <= end_date:
                month_start = current_date.replace(day=1)
                month_end_day = calendar.monthrange(current_date.year, current_date.month)[1]
                month_end = current_date.replace(day=month_end_day)

                label = month_start.strftime('%Y-%m')
                if label not in labels:
                    labels.append(label)

                month_records = records.filter(date__range=[month_start, month_end])
                for record in month_records:
                    if record.time > AttendanceManager.IN_TIME_END:
                        arrival_counts[label]['late'] += 1
                    elif record.time < AttendanceManager.IN_TIME_START:
                        arrival_counts[label]['early'] += 1
                    else:
                        arrival_counts[label]['on_time'] += 1
                    arrival_counts[label]['total'] += 1

                if current_date.month == 12:
                    current_date = current_date.replace(year=current_date.year + 1, month=1, day=1)
                else:
                    current_date = current_date.replace(month=current_date.month + 1, day=1)
        elif interval_type == 'yearly':
            current_date = start_date
            while current_date <= end_date:
                year_start = date(current_date.year, 1, 1)
                year_end = date(current_date.year, 12, 31)

                label = str(current_date.year)
                if label not in labels:
                    labels.append(label)

                year_records = records.filter(date__range=[year_start, year_end])
                for record in year_records:
                    if record.time > AttendanceManager.IN_TIME_END:
                        arrival_counts[label]['late'] += 1
                    elif record.time < AttendanceManager.IN_TIME_START:
                        arrival_counts[label]['early'] += 1
                    else:
                        arrival_counts[label]['on_time'] += 1
                    arrival_counts[label]['total'] += 1

                current_date = date(current_date.year + 1, 1, 1)

        # Calculate counts
        late_data = [0] * len(labels)
        on_time_data = [0] * len(labels)
        early_data = [0] * len(labels)

        for i, label in enumerate(labels):
            late_data[i] = arrival_counts[label]['late']
            on_time_data[i] = arrival_counts[label]['on_time']
            early_data[i] = arrival_counts[label]['early']

        return {
            'labels': labels,
            'late': late_data,
            'on_time': on_time_data,
            'early': early_data,
        }

    @staticmethod
    def get_attendance_percentage_trends(start_date, end_date, interval_type='daily'):
        """
        Calculates attendance trends: number of present and absent employees per interval.
        """
        total_employees = Employee.objects.count()
        if total_employees == 0:
            return {'labels': [], 'present': [], 'absent': []}  # Return empty arrays if no employees

        present_counts = defaultdict(int)
        labels = []

        # Determine intervals and populate counts of unique present employees
        if interval_type == 'daily':
            current_date = start_date
            while current_date <= end_date:
                label = current_date.strftime('%a %d')  # e.g., Mon 01
                labels.append(label)
                present_count = AttendanceRecord.objects.filter(
                    date=current_date, attendance_type='IN'
                ).values('employee').distinct().count()
                present_counts[label] = present_count
                current_date += timedelta(days=1)
        elif interval_type == 'weekly':
            current_date = start_date
            while current_date <= end_date:
                week_start = current_date - timedelta(days=current_date.weekday())
                week_end = week_start + timedelta(days=6)
                label = f"Week of {week_start.strftime('%b %d')}"  # e.g., Week of Jan 01
                if label not in labels:
                    labels.append(label)

                present_count = AttendanceRecord.objects.filter(
                    date__range=[week_start, week_end], attendance_type='IN'
                ).values('employee').distinct().count()
                present_counts[label] = present_count
                current_date = week_end + timedelta(days=1)
        elif interval_type == 'monthly':
            current_date = start_date
            while current_date <= end_date:
                month_start = current_date.replace(day=1)
                month_end_day = calendar.monthrange(current_date.year, current_date.month)[1]
                month_end = current_date.replace(day=month_end_day)

                label = month_start.strftime('%b %Y')  # e.g., Jan 2024
                if label not in labels:
                    labels.append(label)

                present_count = AttendanceRecord.objects.filter(
                    date__range=[month_start, month_end], attendance_type='IN'
                ).values('employee').distinct().count()
                present_counts[label] = present_count

                if current_date.month == 12:
                    current_date = current_date.replace(year=current_date.year + 1, month=1, day=1)
                else:
                    current_date = current_date.replace(month=current_date.month + 1, day=1)
        elif interval_type == 'yearly':
            current_date = start_date
            while current_date <= end_date:
                year_start = date(current_date.year, 1, 1)
                year_end = date(current_date.year, 12, 31)

                label = str(current_date.year)  # e.g., 2024
                if label not in labels:
                    labels.append(label)

                present_count = AttendanceRecord.objects.filter(
                    date__range=[year_start, year_end], attendance_type='IN'
                ).values('employee').distinct().count()
                present_counts[label] = present_count

                current_date = date(current_date.year + 1, 1, 1)

        # Calculate present and absent counts for each label
        present_data = [present_counts.get(label, 0) for label in labels]
        absent_data = [total_employees - present for present in present_data]  # Absent = Total - Present

        return {
            'labels': labels,
            'present': present_data,
            'absent': absent_data,
        }

    @staticmethod
    def get_period_dates(today, period):
        """
        Returns the start and end dates for a given period relative to today.
        """
        if period == 'today':
            start_date = today
            end_date = today
        elif period == 'week':
            start_date = today - timedelta(days=today.weekday())  # Monday of current week
            end_date = start_date + timedelta(days=6)  # Sunday of current week
        elif period == 'month':
            start_date = today.replace(day=1)
            end_date = today  # Up to today in the current month
        elif period == 'year':
            start_date = date(today.year, 1, 1)
            end_date = today  # Up to today in the current year
        elif period == 'yesterday':
            start_date = today - timedelta(days=1)
            end_date = today - timedelta(days=1)
        else:  # Default to the current month if an invalid period is provided
            start_date = today.replace(day=1)
            end_date = today
        return start_date, end_date

    @staticmethod
    def get_leave_distribution():
        """
        Fetches and aggregates leave data from LeaveHistory to provide distribution.
        This is a placeholder for dynamic data. You might need to adjust
        based on how leave types are managed in your system.
        """
        total_leaves_taken_all_time = LeaveHistory.objects.aggregate(Sum('leaves_taken'))['leaves_taken__sum'] or 0

        if total_leaves_taken_all_time > 0:
            # Distribute dynamically based on total. Example: 30% sick, 45% vacation, 20% casual, 5% other
            sick = round(total_leaves_taken_all_time * 0.30)
            vacation = round(total_leaves_taken_all_time * 0.45)
            casual = round(total_leaves_taken_all_time * 0.20)
            other = total_leaves_taken_all_time - (sick + vacation + casual)
        else:
            # If no leaves taken, provide a default small distribution for chart visibility
            # or ensure the chart logic on frontend handles empty data gracefully.
            sick, vacation, casual, other = 0, 0, 0, 0
            # To ensure the chart *always* renders something if there are no leaves taken yet,
            # we could return minimal dummy data like this for visualization:
            # return {
            #     'labels': ['Sick Leave', 'Vacation Leave', 'Casual Leave', 'Other'],
            #     'data': [1, 1, 1, 1] # Small dummy values if total_leaves_taken_all_time is 0
            # }

        return {
            'labels': ['Sick Leave', 'Vacation Leave', 'Casual Leave', 'Other'],
            'data': [sick, vacation, casual, other]
        }
