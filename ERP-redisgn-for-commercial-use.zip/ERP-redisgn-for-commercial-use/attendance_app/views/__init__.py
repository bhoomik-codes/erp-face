# attendance_app/views/__init__.py
# This file will import all views from the sub-modules
from .auth_views import *
from .admin_views import *
from .attendance_views import *
from .api_views import *
