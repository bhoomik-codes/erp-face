# attendance_app/views/admin_views.py
import json
import random
from datetime import date, timedelta, datetime, time
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.utils import timezone
from django.db.models import Max, Sum, DurationField, F
from django.template.loader import render_to_string
from django.http import JsonResponse, HttpResponse
import logging
import csv
from io import StringIO, BytesIO  # Import BytesIO here
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch

from ..models import Employee, AttendanceRecord, LocationSetting
from ..services.attendance_manager import AttendanceManager

logger = logging.getLogger(__name__)


@login_required
def admin_dashboard_view(request):
    """
    Renders the admin dashboard with summary statistics and charts, now with period filters.
    """
    # Get filter period from request, default to 'month'
    filter_period = request.GET.get('period', 'month')

    today = timezone.localdate()
    start_date, end_date = AttendanceManager.get_period_dates(today, filter_period)

    # --- Calculations for Dashboard Cards and Lists ---

    # Total Employees (remains static, not affected by period filter)
    total_employees = Employee.objects.count()

    # Get a QuerySet of all employees for filtering operations
    all_employees_queryset = Employee.objects.all()

    # Get all relevant attendance records for the selected period
    period_attendance_records = AttendanceRecord.objects.filter(
        date__range=[start_date, end_date],
        attendance_type__in=['IN', 'OUT', 'LUNCH_IN', 'LUNCH_OUT', 'BREAK_IN', 'BREAK_OUT']
        # Include all types for accurate daily summary
    ).select_related('employee').order_by('employee', 'date', 'time')

    # Calculate daily summaries using AttendanceManager's method
    daily_summaries = AttendanceManager.calculate_daily_summary(period_attendance_records)

    total_attendance_hours_all = 0
    total_overtime_all = 0
    present_employee_ids_in_period = set()
    employee_period_hours = {}  # Stores aggregated hours per employee for the period

    STANDARD_WORK_HOURS_PER_DAY = 8

    # Aggregate data from daily summaries
    for summary in daily_summaries:
        employee_obj = summary['employee']
        total_hours_for_day = summary['total_hours']

        # Add to set of present employees for absentees calculation
        present_employee_ids_in_period.add(employee_obj.id)

        # Initialize or update employee's total hours for the period
        if employee_obj.employee_id not in employee_period_hours:
            employee_period_hours[employee_obj.employee_id] = {
                'employee': employee_obj,
                'total_hours': 0,
                'days_present': 0  # Count days with IN/OUT records
            }

        employee_period_hours[employee_obj.employee_id]['total_hours'] += total_hours_for_day
        if total_hours_for_day > 0:  # Only count days with actual work
            employee_period_hours[employee_obj.employee_id]['days_present'] += 1

    # Calculate total attendance hours across all employees
    total_attendance_hours_all = sum(data['total_hours'] for data in employee_period_hours.values())

    # Calculate total overtime across all employees for the period
    for emp_data in employee_period_hours.values():
        if emp_data['days_present'] > 0:
            # Corrected: Use STANDARD_WORK_HOURS_PER_DAY * emp_data['days_present']
            expected_hours_for_period = STANDARD_WORK_HOURS_PER_DAY * emp_data['days_present']
            if emp_data['total_hours'] > expected_hours_for_period:
                total_overtime_all += (emp_data['total_hours'] - expected_hours_for_period)

    # Calculate total absentees for the selected period
    total_absentees_count = all_employees_queryset.exclude(
        id__in=list(present_employee_ids_in_period)
    ).count()

    # Top 5 Absentees (employees who had no 'IN' record in the period)
    top_5_absentees = all_employees_queryset.exclude(
        id__in=list(present_employee_ids_in_period)
    ).order_by('name')[:5]

    # Top 5 Employees by Max Attendance (Total Hours for the period)
    top_5_max_attendance = sorted(
        [data for data in employee_period_hours.values() if data['total_hours'] > 0],
        key=lambda x: x['total_hours'],
        reverse=True
    )[:5]

    # Top 5 Employees by Overtime Work (for the period)
    overtime_employees_list = []
    for emp_data in employee_period_hours.values():
        if emp_data['days_present'] > 0:
            expected_hours = STANDARD_WORK_HOURS_PER_DAY * emp_data['days_present']
            if emp_data['total_hours'] > expected_hours:
                emp_data['overtime_hours'] = emp_data['total_hours'] - expected_hours
                overtime_employees_list.append(emp_data)
    top_5_overtime = sorted(
        overtime_employees_list,
        key=lambda x: x['overtime_hours'],
        reverse=True
    )[:5]

    context = {
        'total_employees': total_employees,
        'total_attendance_hours_all': f"{total_attendance_hours_all:.1f}" if total_attendance_hours_all else "N/A",
        'total_overtime_all': f"{total_overtime_all:.1f}" if total_overtime_all else "N/A",
        'total_absentees_count': total_absentees_count,
        'top_5_absentees': top_5_absentees,
        'top_5_max_attendance': top_5_max_attendance,
        'top_5_overtime': top_5_overtime,
        'filter_period': filter_period,
        'current_page': 'dashboard'
    }
    return render(request, 'attendance_app/admin_dashboard.html', context)


@login_required
def get_dashboard_data(request):
    """
    AJAX endpoint to fetch filtered dashboard data.
    This logic mirrors admin_dashboard_view but returns JSON.
    """
    filter_period = request.GET.get('period', 'month')
    today = timezone.localdate()
    start_date, end_date = AttendanceManager.get_period_dates(today, filter_period)

    all_employees_queryset = Employee.objects.all()

    period_attendance_records = AttendanceRecord.objects.filter(
        date__range=[start_date, end_date],
        attendance_type__in=['IN', 'OUT', 'LUNCH_IN', 'LUNCH_OUT', 'BREAK_IN', 'BREAK_OUT']
    ).select_related('employee').order_by('employee', 'date', 'time')

    daily_summaries = AttendanceManager.calculate_daily_summary(period_attendance_records)

    total_attendance_hours_all = 0
    total_overtime_all = 0
    present_employee_ids_in_period = set()
    employee_period_hours = {}

    STANDARD_WORK_HOURS_PER_DAY = 8

    for summary in daily_summaries:
        employee_obj = summary['employee']
        total_hours_for_day = summary['total_hours']

        present_employee_ids_in_period.add(employee_obj.id)

        if employee_obj.employee_id not in employee_period_hours:
            employee_period_hours[employee_obj.employee_id] = {
                'employee': employee_obj,
                'total_hours': 0,
                'days_present': 0
            }

        employee_period_hours[employee_obj.employee_id]['total_hours'] += total_hours_for_day
        if total_hours_for_day > 0:
            employee_period_hours[employee_obj.employee_id]['days_present'] += 1

    total_attendance_hours_all = sum(data['total_hours'] for data in employee_period_hours.values())

    for emp_data in employee_period_hours.values():
        if emp_data['days_present'] > 0:
            expected_hours_for_period = STANDARD_WORK_HOURS_PER_DAY * emp_data['days_present']
            if emp_data['total_hours'] > expected_hours_for_period:
                total_overtime_all += (emp_data['total_hours'] - expected_hours_for_period)

    total_absentees_count = all_employees_queryset.exclude(
        id__in=list(present_employee_ids_in_period)
    ).count()

    absent_employees_in_period = all_employees_queryset.exclude(
        id__in=list(present_employee_ids_in_period)
    ).order_by('name')[:5]

    top_5_max_attendance = sorted(
        [data for data in employee_period_hours.values() if data['total_hours'] > 0],
        key=lambda x: x['total_hours'],
        reverse=True
    )[:5]

    overtime_employees_list = []
    for emp_data in employee_period_hours.values():
        if emp_data['days_present'] > 0:
            expected_hours = STANDARD_WORK_HOURS_PER_DAY * emp_data['days_present']
            if emp_data['total_hours'] > expected_hours:
                emp_data['overtime_hours'] = emp_data['total_hours'] - expected_hours
                overtime_employees_list.append(emp_data)
    top_5_overtime = sorted(
        overtime_employees_list,
        key=lambda x: x['overtime_hours'],
        reverse=True
    )[:5]

    data = {
        'total_attendance_hours_all': f"{total_attendance_hours_all:.1f}" if total_attendance_hours_all else "N/A",
        'total_overtime_all': f"{total_overtime_all:.1f}" if total_overtime_all else "N/A",
        'total_absentees_count': total_absentees_count,
        'top_5_absentees_html': render_to_string(
            'attendance_app/partials/top_absentees_list.html',
            {'top_5_absentees': absent_employees_in_period, 'filter_period': filter_period}
        ),
        'top_5_max_attendance_html': render_to_string(
            'attendance_app/partials/top_max_attendance_list.html',
            {'top_5_max_attendance': top_5_max_attendance, 'filter_period': filter_period}
        ),
        'top_5_overtime_html': render_to_string(
            'attendance_app/partials/top_overtime_list.html',
            {'top_5_overtime': top_5_overtime, 'filter_period': filter_period}
        ),
    }
    return JsonResponse(data)


@login_required(login_url="admin_login")
def admin_settings_view(request):
    """
    Admin settings page to configure office location for geofencing.
    """
    settings_obj = LocationSetting.objects.first()
    context = {
        'latitude': settings_obj.latitude if settings_obj else None,
        'longitude': settings_obj.longitude if settings_obj else None,
        'radius_meters': settings_obj.radius_meters if settings_obj else 500,
        'current_page': 'settings'
    }
    return render(request, 'attendance_app/admin_settings.html', context)


@login_required(login_url='admin_login')
def attendance_report(request):
    """
    Renders the attendance report page with initial data based on filters.
    By default, shows records for today in ascending order of time.
    """
    employees = Employee.objects.all().order_by('name')

    filter_start_date_str = request.GET.get('start_date')
    filter_end_date_str = request.GET.get('end_date')
    filter_employee_ids_list = request.GET.getlist('employee_ids[]')
    filter_total_hours_lt = request.GET.get('total_hours_lt')

    # If no dates are provided, default to today's date
    today_iso = timezone.localdate().isoformat()
    if not filter_start_date_str:
        filter_start_date_str = today_iso
    if not filter_end_date_str:
        filter_end_date_str = today_iso

    # Pass filter values to the template for initial rendering (or for JS to pick up)
    context = {
        'employees': employees,  # Pass all employees for the select2 dropdown
        'filter_start_date': filter_start_date_str,
        'filter_end_date': filter_end_date_str,
        'filter_employee_ids': filter_employee_ids_list,
        # 'filter_attendance_type': filter_attendance_type, # Removed as it's not in the form
        'filter_total_hours_lt': filter_total_hours_lt,
        'current_page': 'view_attendance'

    }

    return render(request, 'attendance_app/view_attendance_records.html', context)


@login_required(login_url='admin_login')
def get_attendance_table(request):
    """
    AJAX endpoint to fetch and return the rendered attendance table body based on filters.
    This is called by attendance_report_scripts.js.
    """
    filter_start_date_str = request.GET.get('start_date')
    filter_end_date_str = request.GET.get('end_date')
    filter_employee_ids_list = request.GET.getlist('employee_ids[]')
    filter_attendance_type = request.GET.get('attendance_type')  # Keep for AttendanceManager filter
    filter_total_hours_lt = request.GET.get('total_hours_lt')

    # If no dates are provided, default to today's date for the AJAX call
    today_iso = timezone.localdate().isoformat()
    if not filter_start_date_str:
        filter_start_date_str = today_iso
    if not filter_end_date_str:
        filter_end_date_str = today_iso

    attendance_summary = AttendanceManager.get_filtered_attendance_summary(
        filter_start_date_str, filter_end_date_str, filter_employee_ids_list,
        filter_attendance_type, filter_total_hours_lt
    )

    # Process each record for overtime and the "zero working hours" scenario
    today_date = timezone.localdate()  # Get today's date once
    processed_records = []

    for record in attendance_summary:
        standard_work_hours = 8.0  # Use float for consistency in calculations

        # Convert total_working_hours to float if it's a string
        try:
            current_total_working_hours = float(record.get('total_working_hours', 0.0))
        except (ValueError, TypeError):
            current_total_working_hours = 0.0  # Default to 0 if conversion fails

        # Parse the record's date string to a date object for comparison
        record_date_obj = None
        try:
            record_date_obj = datetime.strptime(record['date'], '%Y-%m-%d').date()
        except (ValueError, TypeError):
            logger.error(
                f"Could not parse date '{record.get('date')}' for employee {record.get('employee_id')}. Skipping 'IN but no OUT' logic for this record.")

        # Handle "IN but no OUT" scenario: if in_time exists, current_total_working_hours is 0,
        # AND the record date is NOT today.
        if record.get(
                'in_time') and current_total_working_hours == 0.0 and record_date_obj and record_date_obj != today_date:
            try:
                # Parse in_time from string (e.g., "10:00 AM") to time object
                in_time_obj = datetime.strptime(record['in_time'], '%I:%M %p').time()

                # Define the default out time as 7:00 PM
                default_out_time_obj = time(19, 0)  # 7:00 PM

                # Create dummy datetime objects for calculation (date doesn't matter, just for timedelta)
                dummy_date_for_calc = date(2000, 1, 1)
                in_datetime = datetime.combine(dummy_date_for_calc, in_time_obj)
                out_datetime = datetime.combine(dummy_date_for_calc, default_out_time_obj)

                # Calculate duration. If in_time is after 7 PM, it means they might have clocked in late,
                # so consider 7 PM as the end of the standard day, and calculate hours
                # only until 7 PM. If in_time is already past 7 PM, assign 0 hours for this rule.
                if in_datetime < out_datetime:
                    duration = out_datetime - in_datetime
                    calculated_hours = duration.total_seconds() / 3600.0
                else:
                    calculated_hours = 0.0  # If IN time is after or at 7 PM, consider 0 hours for this specific rule

                record['total_working_hours'] = calculated_hours
                current_total_working_hours = calculated_hours  # Update for overtime calculation

            except ValueError:
                logger.warning(
                    f"Could not parse in_time '{record.get('in_time')}' for employee {record.get('employee_id')}. Total working hours remains 0.")
                record['total_working_hours'] = 0.0  # Keep as 0 if parsing fails
                current_total_working_hours = 0.0

        # Format total_working_hours to 2 decimal places for display
        record['total_working_hours'] = f"{current_total_working_hours:.2f}"

        # Calculate Overtime based on the (potentially updated and formatted) total_working_hours
        # Ensure current_total_working_hours is float before calculation
        try:
            total_hours_float = float(record['total_working_hours'])
        except (ValueError, TypeError):
            total_hours_float = 0.0  # Fallback if for some reason it's not a valid float

        record['overtime_hours'] = f"{max(0.0, total_hours_float - standard_work_hours):.2f}"
        processed_records.append(record)

    # Sort records by 'time' in ascending order for today's records
    # Assuming 'time' is available in the record dictionary and is parseable (e.g., "10:00 AM")
    # This sorting is applied after all processing, ensuring the "IN but no OUT" logic is applied first.
    def get_sort_key(item):
        try:
            # Attempt to parse 'in_time' first, then 'out_time' if 'in_time' is missing
            time_str = item.get('in_time') or item.get('out_time')
            if time_str:
                return datetime.strptime(time_str, '%I:%M %p').time()
            return time.min  # Fallback for records with no time
        except (ValueError, TypeError):
            return time.min  # Handle parsing errors by putting them at the beginning

    # Get sort parameters from request for dynamic sorting
    sort_by = request.GET.get('sort_by', 'in_time')  # Default to 'in_time'
    sort_order = request.GET.get('sort_order', 'asc')  # Default to 'asc'

    # Define a generic sort key function
    def dynamic_sort_key(item):
        value = item.get(sort_by)
        if value is None or value == '-':
            # Handle None or '-' values for sorting, push them to end/beginning
            return (float('-inf') if sort_order == 'asc' else float('inf')) if sort_by in ['total_working_hours',
                                                                                           'overtime_hours'] else ''

        if 'time' in sort_by:  # For time fields (in_time, out_time, etc.)
            try:
                # Handle cases where time might be 'In progress...' or similar
                if isinstance(value, str) and ('progress' in value.lower() or value == '-'):
                    return time.max if sort_order == 'asc' else time.min  # Put 'In progress...' at the end for asc, start for desc
                return datetime.strptime(value, '%I:%M %p').time()
            except (ValueError, TypeError):
                return time.min  # Fallback for unparseable times
        elif 'hours' in sort_by:  # For numeric hours fields
            try:
                # Remove " hours" suffix and convert to float
                return float(str(value).replace(' hours', ''))
            except (ValueError, TypeError):
                return 0.0  # Fallback for non-numeric hours
        elif 'date' in sort_by:  # For date field
            try:
                return datetime.strptime(value, '%Y-%m-%d').date()
            except (ValueError, TypeError):
                return date.min  # Fallback for unparseable dates
        return value  # Default for other string fields (name, id)

    # Apply sorting based on request parameters
    sorted_records = sorted(processed_records, key=dynamic_sort_key, reverse=(sort_order == 'desc'))

    html = render_to_string(
        'attendance_app/partials/attendance_table_body.html',
        {'attendance_records': sorted_records},  # Use sorted_records here
        request=request
    )
    return JsonResponse({'html': html})


@login_required(login_url='admin_login')
def export_attendance_csv(request):
    """
    Exports attendance data to CSV format.
    """
    filter_start_date_str = request.GET.get('start_date')
    filter_end_date_str = request.GET.get('end_date')
    filter_employee_ids_list = request.GET.getlist('employee_ids[]')
    filter_attendance_type = request.GET.get('attendance_type')
    filter_total_hours_lt = request.GET.get('total_hours_lt')

    # If no dates are provided, default to today's date for the export
    today_iso = timezone.localdate().isoformat()
    if not filter_start_date_str:
        filter_start_date_str = today_iso
    if not filter_end_date_str:
        filter_end_date_str = today_iso

    attendance_summary = AttendanceManager.get_filtered_attendance_summary(
        filter_start_date_str, filter_end_date_str, filter_employee_ids_list,
        filter_attendance_type, filter_total_hours_lt
    )

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="attendance_report.csv"'

    writer = csv.writer(response)
    # Define headers, including Overtime and excluding Remarks
    headers = [
        'Employee Name', 'Employee ID', 'Date', 'In Time', 'Out Time',
        'Lunch In', 'Lunch Out', 'Break In', 'Break Out', 'Total Working Hours', 'Overtime'
    ]
    writer.writerow(headers)

    today_date = timezone.localdate()  # Get today's date once
    for record in attendance_summary:
        standard_work_hours = 8.0  # Use float for consistency
        calculated_total_working_hours = record.get('total_working_hours', 0.0)

        # Convert total_working_hours to float if it's a string
        try:
            calculated_total_working_hours = float(calculated_total_working_hours)
        except (ValueError, TypeError):
            calculated_total_working_hours = 0.0

        # Parse the record's date string to a date object for comparison
        record_date_obj = None
        try:
            record_date_obj = datetime.strptime(record['date'], '%Y-%m-%d').date()
        except (ValueError, TypeError):
            pass  # If date parsing fails, record_date_obj remains None

        # Handle "IN but no OUT" scenario for export (only for past days)
        if record.get(
                'in_time') and calculated_total_working_hours == 0.0 and record_date_obj and record_date_obj != today_date:
            try:
                in_time_obj = datetime.strptime(record['in_time'], '%I:%M %p').time()
                default_out_time_obj = time(19, 0)  # 7:00 PM

                dummy_date_for_calc = date(2000, 1, 1)
                in_datetime = datetime.combine(dummy_date_for_calc, in_time_obj)
                out_datetime = datetime.combine(dummy_date_for_calc, default_out_time_obj)

                if in_datetime < out_datetime:
                    duration = out_datetime - in_datetime
                    calculated_total_working_hours = duration.total_seconds() / 3600.0
                else:
                    calculated_total_working_hours = 0.0
            except ValueError:
                calculated_total_working_hours = 0.0

        overtime_hours = max(0.0, calculated_total_working_hours - standard_work_hours)

        writer.writerow([
            record.get('employee_name', '-'),
            record.get('employee_id', '-'),
            record.get('date', '-'),
            record.get('in_time', '-'),
            record.get('out_time', '-'),
            record.get('lunch_in_time', '-'),
            record.get('lunch_out_time', '-'),
            record.get('break_in_time', '-'),
            record.get('break_out_time', '-'),
            f"{calculated_total_working_hours:.2f} hours",
            f"{overtime_hours:.2f} hours"
        ])
    return response


@login_required(login_url='admin_login')
def export_attendance_xlsx(request):
    """
    Exports attendance data to XLSX format.
    """
    filter_start_date_str = request.GET.get('start_date')
    filter_end_date_str = request.GET.get('end_date')
    filter_employee_ids_list = request.GET.getlist('employee_ids[]')
    filter_attendance_type = request.GET.get('attendance_type')
    filter_total_hours_lt = request.GET.get('total_hours_lt')

    # If no dates are provided, default to today's date for the export
    today_iso = timezone.localdate().isoformat()
    if not filter_start_date_str:
        filter_start_date_str = today_iso
    if not filter_end_date_str:
        filter_end_date_str = today_iso

    attendance_summary = AttendanceManager.get_filtered_attendance_summary(
        filter_start_date_str, filter_end_date_str, filter_employee_ids_list,
        filter_attendance_type, filter_total_hours_lt
    )

    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Attendance Report"

    # Define headers
    headers = [
        'Employee Name', 'Employee ID', 'Date', 'In Time', 'Out Time',
        'Lunch In', 'Lunch Out', 'Break In', 'Break Out', 'Total Working Hours', 'Overtime'
    ]
    sheet.append(headers)

    # Apply bold style to headers
    header_font = Font(bold=True)
    for cell in sheet[1]:
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))

    today_date = timezone.localdate()  # Get today's date once
    # Populate data
    for record in attendance_summary:
        standard_work_hours = 8.0
        calculated_total_working_hours = record.get('total_working_hours', 0.0)

        # Convert total_working_hours to float if it's a string
        try:
            calculated_total_working_hours = float(calculated_total_working_hours)
        except (ValueError, TypeError):
            calculated_total_working_hours = 0.0

        # Parse the record's date string to a date object for comparison
        record_date_obj = None
        try:
            record_date_obj = datetime.strptime(record['date'], '%Y-%m-%d').date()
        except (ValueError, TypeError):
            pass  # If date parsing fails, record_date_obj remains None

        # Handle "IN but no OUT" scenario for export (only for past days)
        if record.get(
                'in_time') and calculated_total_working_hours == 0.0 and record_date_obj and record_date_obj != today_date:
            try:
                in_time_obj = datetime.strptime(record['in_time'], '%I:%M %p').time()
                default_out_time_obj = time(19, 0)  # 7:00 PM

                dummy_date_for_calc = date(2000, 1, 1)
                in_datetime = datetime.combine(dummy_date_for_calc, in_time_obj)
                out_datetime = datetime.combine(dummy_date_for_calc, default_out_time_obj)

                if in_datetime < out_datetime:
                    duration = out_datetime - in_datetime
                    calculated_total_working_hours = duration.total_seconds() / 3600.0
                else:
                    calculated_total_working_hours = 0.0
            except ValueError:
                calculated_total_working_hours = 0.0

        overtime_hours = max(0.0, calculated_total_working_hours - standard_work_hours)

        row_data = [
            record.get('employee_name', '-'),
            record.get('employee_id', '-'),
            record.get('date', '-'),
            record.get('in_time', '-'),
            record.get('out_time', '-'),
            record.get('lunch_in_time', '-'),
            record.get('lunch_out_time', '-'),
            record.get('break_in_time', '-'),
            record.get('break_out_time', '-'),
            f"{calculated_total_working_hours:.2f} hours",
            f"{overtime_hours:.2f} hours"
        ]
        sheet.append(row_data)

    # Adjust column widths
    for col in sheet.columns:
        max_length = 0
        column = col[0].column_letter  # Get the column name
        for cell in col:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = (max_length + 2)
        sheet.column_dimensions[column].width = adjusted_width

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename="attendance_report.xlsx"'
    workbook.save(response)
    return response


@login_required(login_url='admin_login')
def export_attendance_pdf(request):
    """
    Exports attendance data to PDF format.
    """
    filter_start_date_str = request.GET.get('start_date')
    filter_end_date_str = request.GET.get('end_date')
    filter_employee_ids_list = request.GET.getlist('employee_ids[]')
    filter_attendance_type = request.GET.get('attendance_type')
    filter_total_hours_lt = request.GET.get('total_hours_lt')

    # If no dates are provided, default to today's date for the export
    today_iso = timezone.localdate().isoformat()
    if not filter_start_date_str:
        filter_start_date_str = today_iso
    if not filter_end_date_str:
        filter_end_date_str = today_iso

    attendance_summary = AttendanceManager.get_filtered_attendance_summary(
        filter_start_date_str, filter_end_date_str, filter_employee_ids_list,
        filter_attendance_type, filter_total_hours_lt
    )

    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=landscape(letter))
    styles = getSampleStyleSheet()

    elements = []

    # Title
    title_style = styles['h1']
    title_style.alignment = 1  # Center
    elements.append(Paragraph("Attendance Report", title_style))
    elements.append(Spacer(1, 0.2 * inch))

    # Table Data
    data = []
    # Headers
    headers = [
        'Employee Name', 'Employee ID', 'Date', 'In Time', 'Out Time',
        'Lunch In', 'Lunch Out', 'Break In', 'Break Out', 'Total Working Hours', 'Overtime'
    ]
    data.append(headers)

    today_date = timezone.localdate()
    processed_records_for_pdf = []  # Store processed records to calculate max widths

    for record in attendance_summary:
        standard_work_hours = 8.0
        calculated_total_working_hours = record.get('total_working_hours', 0.0)

        try:
            calculated_total_working_hours = float(calculated_total_working_hours)
        except (ValueError, TypeError):
            calculated_total_working_hours = 0.0

        record_date_obj = None
        try:
            record_date_obj = datetime.strptime(record['date'], '%Y-%m-%d').date()
        except (ValueError, TypeError):
            pass

        if record.get(
                'in_time') and calculated_total_working_hours == 0.0 and record_date_obj and record_date_obj != today_date:
            try:
                in_time_obj = datetime.strptime(record['in_time'], '%I:%M %p').time()
                default_out_time_obj = time(19, 0)

                dummy_date_for_calc = date(2000, 1, 1)
                in_datetime = datetime.combine(dummy_date_for_calc, in_time_obj)
                out_datetime = datetime.combine(dummy_date_for_calc, default_out_time_obj)

                if in_datetime < out_datetime:
                    duration = out_datetime - in_datetime
                    calculated_total_working_hours = duration.total_seconds() / 3600.0
                else:
                    calculated_total_working_hours = 0.0
            except ValueError:
                calculated_total_working_hours = 0.0

        overtime_hours = max(0.0, calculated_total_working_hours - standard_work_hours)

        # Store formatted values for PDF table
        processed_records_for_pdf.append([
            record.get('employee_name', '-'),
            record.get('employee_id', '-'),
            record.get('date', '-'),
            record.get('in_time', '-'),
            record.get('out_time', '-'),
            record.get('lunch_in_time', '-'),
            record.get('lunch_out_time', '-'),
            record.get('break_in_time', '-'),
            record.get('break_out_time', '-'),
            f"{calculated_total_working_hours:.2f} hours",
            f"{overtime_hours:.2f} hours"
        ])

    # Add processed records to data list for the table
    data.extend(processed_records_for_pdf)

    # Calculate column widths dynamically based on content
    num_columns = len(headers)
    table_width = landscape(letter)[0] - 2 * inch  # Page width minus 1 inch margin on each side

    # Initialize max_widths with header lengths (in characters)
    max_widths = [len(header) for header in headers]

    # Iterate through all data (including headers) to find max content length for each column
    for row in data:
        for i, cell_value in enumerate(row):
            max_widths[i] = max(max_widths[i], len(str(cell_value)))

    # Convert character widths to ReportLab units (points).
    # A rough estimate: 1 character is about 6 points for Helvetica-Bold 10pt.
    # Add a small padding (e.g., 5 points per side = 10 points total per column).
    CHAR_POINT_WIDTH = 6  # Rough estimate for character width in points
    COLUMN_PADDING_POINTS = 10  # Additional padding per column

    # Calculate initial column widths based on max content + padding
    initial_col_widths = [(mw * CHAR_POINT_WIDTH) + COLUMN_PADDING_POINTS for mw in max_widths]
    total_initial_width = sum(initial_col_widths)

    col_widths = []
    if total_initial_width > table_width:
        # Scale down if total width exceeds table_width
        scale_factor = table_width / total_initial_width
        col_widths = [w * scale_factor for w in initial_col_widths]
    else:
        # Distribute remaining space if initial widths are too small
        remaining_space = table_width - total_initial_width
        space_per_column = remaining_space / num_columns
        col_widths = [w + space_per_column for w in initial_col_widths]

    # Ensure a minimum width for any column to prevent collapse, if desired
    # min_allowed_width = 0.5 * inch
    # col_widths = [max(min_allowed_width, w) for w in col_widths]

    table = Table(data, colWidths=col_widths)

    # Table Style
    table_style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BOX', (0, 0), (-1, -1), 1, colors.black),
    ])
    table.setStyle(table_style)
    elements.append(table)

    doc.build(elements)

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="attendance_report.pdf"'
    response.write(buffer.getvalue())
    buffer.close()
    return response


@login_required(login_url='admin_login')
def reports_view(request):
    """
    Renders the reports page with dynamic data for various charts.
    """
    today = date.today()

    start_date_weekly = today - timedelta(days=6)
    end_date_weekly = today

    start_date_monthly = today - timedelta(days=29)
    end_date_monthly = today

    start_date_yearly = date(today.year - 1, today.month, today.day)
    end_date_yearly = today

    emotion_trends_data = {
        'weekly': AttendanceManager.get_emotion_trends(start_date_weekly, end_date_weekly, 'daily'),
        'monthly': AttendanceManager.get_emotion_trends(start_date_monthly, end_date_monthly, 'daily'),
        'yearly': AttendanceManager.get_emotion_trends(start_date_yearly, end_date_yearly, 'monthly'),
    }

    late_on_time_trends_data = {
        'weekly': AttendanceManager.get_late_on_time_trends(start_date_weekly, end_date_weekly, 'daily'),
        'monthly': AttendanceManager.get_late_on_time_trends(start_date_monthly, end_date_monthly, 'daily'),
        'yearly': AttendanceManager.get_late_on_time_trends(start_date_yearly, end_date_yearly, 'monthly'),
    }

    attendance_percentage_trends_data = {
        'weekly': AttendanceManager.get_attendance_percentage_trends(start_date_weekly, end_date_weekly, 'daily'),
        'monthly': AttendanceManager.get_attendance_percentage_trends(start_date_monthly, end_date_monthly, 'daily'),
        'yearly': AttendanceManager.get_attendance_percentage_trends(start_date_yearly, end_date_yearly, 'monthly'),
    }

    # Fetches dynamic leave data from AttendanceManager
    leave_data = AttendanceManager.get_leave_distribution()

    context = {
        'report_data': json.dumps({
            'emotionTrends': emotion_trends_data,
            'leaveDistribution': leave_data,
            'arrivalStats': late_on_time_trends_data,
            'attendanceTrends': attendance_percentage_trends_data,
        })
    }
    return render(request, 'attendance_app/reports.html', {**context, 'current_page': 'reports'})
