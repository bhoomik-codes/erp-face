# attendance_app/face_recognizer.py
import face_recognition
import os
import pickle
import numpy as np
from django.conf import settings  # Make sure settings is imported


class FaceRecognitionSystem:
    _instance = None  # To store the singleton instance
    _known_face_encodings = []
    _known_face_names = []
    _known_employee_ids = []  # To store employee IDs associated with encodings

    def __new__(cls, *args, **kwargs):
        """
        Ensures a single instance of FaceRecognitionSystem exists.
        Initializes the instance and loads encodings if not already done.
        """
        if cls._instance is None:
            cls._instance = super(FaceRecognitionSystem, cls).__new__(cls)
            cls._instance.tolerance = kwargs.get('tolerance', 0.6)  # Default tolerance
            cls._instance._load_encodings()  # Load encodings when the singleton is first created
        return cls._instance

    def _get_encodings_file_path(self):
        """Returns the path to the face encodings pickle file."""
        # Ensure MEDIA_ROOT is correctly configured in your Django settings.py
        # E.g., MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
        encodings_dir = os.path.join(settings.MEDIA_ROOT, 'face_data')
        os.makedirs(encodings_dir, exist_ok=True)  # Ensure directory exists
        return os.path.join(encodings_dir, 'known_face_encodings.pkl')

    def _load_encodings(self):
        """Loads known face encodings, names, and employee IDs from the pickle file."""
        encodings_file = self._get_encodings_file_path()
        if os.path.exists(encodings_file):
            try:
                with open(encodings_file, 'rb') as f:
                    data = pickle.load(f)
                    self._known_face_encodings = data.get('encodings', [])
                    self._known_face_names = data.get('names', [])
                    self._known_employee_ids = data.get('employee_ids', [])
                print(f"Loaded {len(self._known_face_encodings)} face encodings from file.")
            except Exception as e:
                print(f"Error loading face encodings from '{encodings_file}': {e}. Starting with empty data.")
                self._known_face_encodings = []
                self._known_face_names = []
                self._known_employee_ids = []
        else:
            print(f"No existing face encodings file found at '{encodings_file}'. Starting fresh.")
            self._known_face_encodings = []
            self._known_face_names = []
            self._known_employee_ids = []

    def _save_encodings(self):
        """Saves current known face encodings, names, and employee IDs to the pickle file."""
        encodings_file = self._get_encodings_file_path()
        data = {
            'encodings': self._known_face_encodings,
            'names': self._known_face_names,
            'employee_ids': self._known_employee_ids
        }
        try:
            with open(encodings_file, 'wb') as f:
                pickle.dump(data, f)
            print(f"Saved {len(self._known_face_encodings)} face encodings to file.")
        except Exception as e:
            print(f"Error saving face encodings to '{encodings_file}': {e}")

    def register_employee(self, employee_id):
        """
        Captures multiple face samples, averages their encodings,
        and adds/updates the encoding in the system and saves to file.
        This method is designed to be called when an employee is registered or updated with a new photo.
        It *does not* handle webcam capture directly here as that's typically done on the frontend.
        Instead, it expects the `employee.photo` field to be set.
        """
        from .models import Employee  # Import here to avoid circular dependency

        try:
            employee = Employee.objects.get(employee_id=employee_id)
            if not employee.photo:
                print(f"Employee {employee.name} (ID: {employee.employee_id}) has no photo to encode.")
                return False

            image_path = employee.photo.path
            print(f"Attempting to load image from: {image_path}")

            if not os.path.exists(image_path):
                print(f"Image file not found at {image_path}. Cannot register face.")
                return False

            image = face_recognition.load_image_file(image_path)
            face_encodings = face_recognition.face_encodings(image)

            if face_encodings:
                new_encoding = face_encodings[0]

                # Check if this employee_id already has an encoding in our in-memory list
                if employee_id in self._known_employee_ids:
                    idx = self._known_employee_ids.index(employee_id)
                    self._known_face_encodings[idx] = new_encoding
                    self._known_face_names[idx] = employee.name
                    print(f"Updated face encoding for existing employee: {employee.name} (ID: {employee_id})")
                else:
                    self._known_face_encodings.append(new_encoding)
                    self._known_face_names.append(employee.name)
                    self._known_employee_ids.append(employee_id)
                    print(f"Registered new face encoding for: {employee.name} (ID: {employee_id})")

                # Update the face_encoding field in the Django model
                employee.face_encoding = pickle.dumps(new_encoding)
                employee.save(update_fields=['face_encoding'])  # Save only this field
                self._save_encodings()  # Save the updated in-memory list to file
                return True
            else:
                print(f"No face found in the photo for employee: {employee.name} (ID: {employee_id})")
                return False
        except Employee.DoesNotExist:
            print(f"Employee with ID {employee_id} not found during registration.")
            return False
        except Exception as e:
            print(f"Error during face registration for employee {employee_id}: {e}")
            return False

    def delete_employee_encoding(self, employee_id):
        """
        Removes a face encoding from the system when an employee is deleted.
        """
        try:
            if employee_id in self._known_employee_ids:
                idx = self._known_employee_ids.index(employee_id)
                self._known_face_encodings.pop(idx)
                self._known_face_names.pop(idx)
                self._known_employee_ids.pop(idx)
                self._save_encodings()  # Save changes to the file system
                print(f"Successfully deleted face encoding for employee ID: {employee_id}")
                return True
            else:
                print(f"Face encoding for employee ID: {employee_id} not found in system.")
                return False
        except Exception as e:
            print(f"Error deleting face encoding for employee ID {employee_id}: {e}")
            return False

    def recognize_face(self, frame):
        """
        Recognize faces in a given frame (expected to be RGB).
        Returns a list of recognized names.
        """
        # No need for cvtColor if frame is already RGB from frontend webcam
        face_locations = face_recognition.face_locations(frame)
        face_encodings = face_recognition.face_encodings(frame, face_locations)

        recognized_names = []
        for face_encoding in face_encodings:
            if not self._known_face_encodings:  # Use _known_face_encodings
                print("No known faces loaded for recognition.")
                return recognized_names

            matches = face_recognition.compare_faces(self._known_face_encodings, face_encoding, self.tolerance)
            name = "Unknown"

            face_distances = face_recognition.face_distance(self._known_face_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)
            if matches[best_match_index]:
                name = self._known_face_names[best_match_index]  # Use _known_face_names

            recognized_names.append(name)
        return recognized_names


# This function ensures that other modules get the *same* instance of FaceRecognitionSystem.
def get_face_recognition_system():
    return FaceRecognitionSystem()

# To ensure the singleton is initialized and encodings are loaded when the app starts.
# This makes sure the system is ready for use without explicit calls in every view.
# FaceRecognitionSystem() # Instantiate the singleton on import of this module.
