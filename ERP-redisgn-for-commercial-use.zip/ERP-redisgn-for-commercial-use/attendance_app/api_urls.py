from django.urls import path
from . import views  # Import your views.py

urlpatterns = [
    # These paths are now relative to the '/api/' prefix from my_project/urls.py
    path('get_employee_leaves/<str:employee_id>/', views.get_employee_leaves, name='api_get_employee_leaves'),
    path('save-location-settings/', views.save_location_settings, name='save_location_settings_api'),
    path('get-location-settings/', views.get_location_settings, name='get_location_settings_api'),
    path('get-current-working-hours/<str:employee_id>/<str:date_str>/', views.get_current_working_hours,
         name='get_current_working_hours'),
    path('check-face-position/', views.check_face_position, name='check_face_position'),
    path('get-attendance-table/', views.get_rendered_attendance_table, name='get_attendance_table'),
    path('health/', views.health_check, name='health_check'),
]
