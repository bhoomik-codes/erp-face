# attendance_app/forms.py
from django import forms
from django.contrib.auth.forms import AuthenticationForm
from .models import Employee, LocationSetting, CustomUser  # Ensure CustomUser is imported if used for AdminLogin


class EmployeeForm(forms.ModelForm):
    """
    Form for creating and updating Employee records.
    Handles 'name', 'employee_id', and 'photo'.
    'face_encoding' is handled programmatically in the view based on 'photo'.
    """

    class Meta:
        model = Employee
        fields = ['name', 'employee_id', 'photo', 'team_members']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'placeholder': 'Employee Full Name'
            }),
            'employee_id': forms.TextInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'placeholder': 'Unique Employee ID'
            }),
            # 'photo' will render as a file input by default, we can add classes if needed
            'photo': forms.FileInput(attrs={
                'class': 'block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100',
            }),
            'team_members': 'hidden'
        }
        labels = {
            'name': 'Full Name',
            'employee_id': 'Employee ID',
            'photo': 'Profile Photo',
        }
        help_texts = {
            'photo': 'Upload a clear photo of the employee\'s face for recognition.',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # You might want to dynamically show/hide team_members based on role
        if self.instance and self.instance.role != 'TEAM_LEADER':
            self.fields['team_members'].widget = forms.HiddenInput()
            self.fields['team_members'].required = False
        else:
            # Filter choices for team_members in the form
            self.fields['team_members'].queryset = Employee.objects.filter(
                role__in=['JUNIOR_DEVELOPER', 'SENIOR_DEVELOPER', 'TRAINEE']
            )

class AdminLoginForm(AuthenticationForm):
    """
    Custom login form for admin users.
    Inherits from Django's built-in AuthenticationForm.
    """
    username = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
            'placeholder': 'Username'
        })
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
            'placeholder': 'Password'
        })
    )

    class Meta:
        model = CustomUser  # Associate with your CustomUser model
        fields = ['username', 'password']


class LocationSettingForm(forms.ModelForm):
    """
    Form for managing the single LocationSetting record.
    Used in admin settings to set geofencing parameters.
    """

    class Meta:
        model = LocationSetting
        fields = ['latitude', 'longitude', 'radius_meters']
        widgets = {
            'latitude': forms.NumberInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'step': 'any',  # Allow decimal input
                'placeholder': 'e.g., 26.9124'
            }),
            'longitude': forms.NumberInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'step': 'any',  # Allow decimal input
                'placeholder': 'e.g., 75.7873'
            }),
            'radius_meters': forms.NumberInput(attrs={
                'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
                'min': '1',  # Ensure radius is at least 1 meter
                'placeholder': 'e.g., 500'
            }),
        }
        labels = {
            'latitude': 'Latitude',
            'longitude': 'Longitude',
            'radius_meters': 'Radius (meters)',
        }
