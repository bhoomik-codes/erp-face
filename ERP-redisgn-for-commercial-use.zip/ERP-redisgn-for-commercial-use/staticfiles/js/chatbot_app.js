// chatbot_view_vanilla.js - Reimplementation of ChatbotView using Vanilla JavaScript

// This code directly manipulates the DOM and manages state without React.

// Ensure the animation styles are in your main CSS file (e.g., admin_styles.css or styles.css)
// Example for CSS:
/*
@keyframes fadeInTranslateUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.animate-fade-in-up {
    animation: fadeInTranslateUp 0.3s ease-out forwards;
}
*/

/**
 * Manages the UI and logic for a single chat message.
 * @param {object} msg - The message object {sender: 'user'|'bot', text: string}.
 * @returns {HTMLElement} The message wrapper div.
 */
function createMessageElement(msg) {
    const messageWrapper = document.createElement('div');
    messageWrapper.className = `flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`;

    const messageBubble = document.createElement('div');
    messageBubble.className = `max-w-[75%] p-2 rounded-lg shadow-sm ${
        msg.sender === 'user'
            ? 'bg-blue-100 text-blue-800 rounded-br-none'
            : 'bg-gray-100 text-gray-800 rounded-bl-none'
    }`;
    const messageText = document.createElement('p');
    messageText.className = "whitespace-pre-wrap";
    messageText.textContent = msg.text;

    messageBubble.appendChild(messageText);
    messageWrapper.appendChild(messageBubble);
    return messageWrapper;
}

/**
 * Creates and manages a chatbot UI element using Vanilla JavaScript.
 * This function takes a container element and an onClose callback.
 *
 * @param {HTMLElement} containerElement - The DOM element where the chatbot UI will be rendered.
 * @param {function} onClose - Callback function to be executed when the chatbot is closed.
 */
function createChatbotView(containerElement, onClose) {
    // --- State Management ---
    let messages = [];
    let inputMessage = '';
    let isTyping = false;

    const csrfToken = document.querySelector('input[name="csrfmiddlewaretoken"]')?.value || '';

    // --- DOM Elements (will be created and updated) ---
    const chatMessagesArea = document.createElement('div');
    const inputField = document.createElement('input');
    const sendButton = document.createElement('button');
    const messagesEndRef = document.createElement('div'); // Used for auto-scrolling

    /**
     * Renders or re-renders the chat messages in the UI.
     */
    function renderMessages() {
        chatMessagesArea.innerHTML = ''; // Clear existing messages

        if (messages.length === 0) {
            const initialMessageDiv = document.createElement('div');
            initialMessageDiv.className = "text-center text-gray-500 italic p-2";
            initialMessageDiv.textContent = "Hi there! Ask me about ERP or check leaves using \"check leaves EMP001\".";
            chatMessagesArea.appendChild(initialMessageDiv);
        }

        messages.forEach(msg => {
            chatMessagesArea.appendChild(createMessageElement(msg));
        });

        if (isTyping) {
            const typingWrapper = document.createElement('div');
            typingWrapper.className = "flex justify-start";
            const typingBubble = document.createElement('div');
            typingBubble.className = "max-w-[75%] p-2 rounded-lg shadow-sm bg-gray-100 text-gray-600 rounded-bl-none";
            const typingText = document.createElement('div');
            typingText.className = "animate-pulse";
            typingText.textContent = "Typing...";
            typingBubble.appendChild(typingText);
            typingWrapper.appendChild(typingBubble);
            chatMessagesArea.appendChild(typingWrapper);
        }

        chatMessagesArea.appendChild(messagesEndRef); // Keep the scroll reference at the end
        messagesEndRef.scrollIntoView({ behavior: 'smooth' }); // Auto-scroll
    }

    /**
     * Updates the UI based on current state.
     */
    function updateUI() {
        renderMessages();
        inputField.disabled = isTyping;
        sendButton.disabled = isTyping || inputMessage.trim() === '';
    }

    /**
     * Fetches employee leave information from your Django backend API.
     * @param {string} employeeId - The ID of the employee.
     * @returns {Promise<object|null>} A promise that resolves with leave data or null.
     */
    const getEmployeeLeaveInfo = async (employeeId) => {
        isTyping = true;
        updateUI(); // Update UI to show typing indicator
        console.log("Fetching employee leave data for:", employeeId.substring(3));
        try {
            const response = await fetch(`/attendance/get-employee-leaves/${employeeId}/`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': csrfToken,
                },
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                const errorMessage = errorData.error || `HTTP error! status: ${response.status}`;
                throw new Error(errorMessage);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            console.error("Error fetching employee leave data:", error);
            const messagesDiv = document.getElementById('messages');
            if (messagesDiv && typeof window.displayMessage === 'function') {
                window.displayMessage(messagesDiv, "Failed to fetch leave data: " + (error.message || "Unknown error."), 'error');
            } else {
                console.warn('displayMessage function not found or messages div not present. Cannot show user-friendly error message.');
            }
            return { error: error.message || "Failed to fetch leave data." };
        } finally {
            isTyping = false;
            updateUI(); // Update UI to hide typing indicator
        }
    };

    /**
     * Calls the Gemini 2.0 Flash API to get a conversational response.
     * @param {string} prompt - The user's input prompt.
     * @returns {Promise<string>} A promise that resolves with the bot's response.
     */
    const callGeminiAPI = async (prompt) => {
        isTyping = true;
        updateUI(); // Update UI to show typing indicator
        try {
            const chatPrompt = `
                You are an AI assistant for an ERP (Enterprise Resource Planning) system, specifically an Attendance Marking System. Your goal is to provide helpful, concise, and accurate information to employees.

                Here are your capabilities:
                1.  **Answer basic queries:** Explain common ERP terms, features, or policies related to attendance.
                2.  **Provide step-by-step guides:** If a user asks "How do I do X in the ERP?", provide clear, numbered instructions.
                3.  **Handle common HR/ERP questions:** Respond to general questions that don't require specific employee data.

                When a user asks about their personal leave balance, tell them that specific employee data retrieval is handled by a separate system component and cannot be accessed through this AI, and ask them to use the "check leaves [employee ID]" command.
                Do NOT try to generate or guess any employee specific data.

                If a query requires specific employee data (like "my leaves", "leaves of employee X"), remind the user to use the command "check leaves [employee ID]".

                Example responses:
                - User: "What is ERP?"
                - AI: "ERP stands for Enterprise Resource Planning. In our system, it helps manage various business processes including attendance, leaves, and employee data."

                - User: "How do I apply for leave?"
                - AI: "To apply for leave ask the HR department or mail the request to hr@vidhema.com"

                - User: "My remaining leaves"
                - AI: "I cannot directly access personal leave data through this chat. Please use the command 'check leaves [your Employee ID]' to get your leave information from the system. For example: 'check leaves EMP001'."

                - User: "How do I do register new employees in the ERP?"
                - AI: "Please follow the steps below to complete the task:
                1.  Login to the ERP system using your admin credentials.
                2.  Navigate to the 'Employees' tab.
                3.  Click on the 'Register Employee' or similar button.
                4.  Fill in the required fields and click 'Save'."

                For any other queries, that you are unsure or not aware of prompt the user to read the contents of the README.md file for their solutions or contact the HR department.

                Now, respond to the user query:
                User query: "${prompt}"
            `;

            let chatHistory = [];
            chatHistory.push({ role: "user", parts: [{ text: chatPrompt }] });

            const payload = { contents: chatHistory };
            const apiKey = "AIzaSyDfQCQVfwEzN0qgZn1O1AE5B3AOa_IIhSE"; // Leave empty for Canvas environment to inject API key
            const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const result = await response.json();

            if (result.candidates && result.candidates.length > 0 &&
                result.candidates[0].content && result.candidates[0].content.parts &&
                result.candidates[0].content.parts.length > 0) {
                const text = result.candidates[0].content.parts[0].text;
                return text;
            } else {
                console.error("Gemini API response structure unexpected:", result);
                return "I'm sorry, I couldn't get a clear response from the AI at the moment. Please try again.";
            }
        } catch (error) {
            console.error("Error calling Gemini API:", error);
            return "I'm having trouble connecting to the AI. Please check your network or try again later.";
        } finally {
            isTyping = false;
            updateUI(); // Update UI to hide typing indicator
        }
    };

    // --- Event Handlers ---
    const handleSendMessage = async () => {
        if (inputMessage.trim() === '') return;

        const userMsg = inputMessage;
        messages = [...messages, { sender: 'user', text: userMsg }];
        inputMessage = '';
        inputField.value = ''; // Clear input field
        updateUI(); // Update UI after user message

        let botResponse = '';

        const leaveMatch = userMsg.toLowerCase().match(/check leaves\s+(emp\d+)/);

        if (leaveMatch) {
            const employeeId = leaveMatch[1].toUpperCase();
            const leaveData = await getEmployeeLeaveInfo(employeeId);
            if (leaveData && !leaveData.error) {
                botResponse = `For Employee ID: ${leaveData.employeeId} (${leaveData.employeeName}):\n` +
                              `Total Leaves Accrued This Year (${leaveData.currentMonth.substring(0, 4)}): ${leaveData.totalLeavesAccruedThisYear}\n` +
                              `Leaves Taken This Year: ${leaveData.leavesTakenThisYear}\n` +
                              `Leaves Remaining: ${leaveData.leavesRemaining}`;
            } else {
                botResponse = `Sorry, I couldn't find leave information for Employee ID: ${employeeId}. ` +
                              (leaveData?.error || "Please double-check the ID or ensure the backend is correctly configured.");
            }
        } else {
            botResponse = await callGeminiAPI(userMsg);
        }

        messages = [...messages, { sender: 'bot', text: botResponse }];
        updateUI(); // Update UI after bot message
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && !isTyping) {
            handleSendMessage();
        }
    };

    const handleInputChange = (e) => {
        inputMessage = e.target.value;
        sendButton.disabled = isTyping || inputMessage.trim() === ''; // Enable/disable send button based on input
    };

    // --- Main Rendering Function ---
    function renderChatbotUI() {
        containerElement.innerHTML = ''; // Clear previous content if re-rendering

        const mainDiv = document.createElement('div');
        mainDiv.className = "flex flex-col h-full bg-white rounded-xl shadow-2xl overflow-hidden border border-gray-300";

        // --- Header ---
        const headerDiv = document.createElement('div');
        headerDiv.className = "bg-blue-600 text-white p-3 flex justify-between items-center rounded-t-xl";
        const titleSpan = document.createElement('span');
        titleSpan.className = "font-semibold text-lg";
        titleSpan.textContent = "Chat Assistant 🤖";
        const closeButton = document.createElement('button');
        closeButton.className = "text-white hover:text-gray-200 text-xl leading-none";
        closeButton.textContent = "✖";
        closeButton.onclick = onClose;

        headerDiv.appendChild(titleSpan);
        headerDiv.appendChild(closeButton);
        mainDiv.appendChild(headerDiv);

        // --- Messages Area ---
        chatMessagesArea.className = "flex-1 p-3 space-y-2 overflow-y-auto text-sm max-h-80 min-h-[120px]";
        mainDiv.appendChild(chatMessagesArea);

        // --- Input Area ---
        const inputAreaDiv = document.createElement('div');
        inputAreaDiv.className = "flex border-t border-gray-300 p-2";

        inputField.type = "text";
        inputField.className = "flex-1 px-3 py-2 text-sm focus:outline-none border rounded-l-lg border-gray-300 focus:border-blue-500";
        inputField.placeholder = "Ask me something...";
        inputField.value = inputMessage;
        inputField.oninput = handleInputChange;
        inputField.onkeypress = handleKeyPress;

        sendButton.textContent = "Send";
        sendButton.className = "px-4 bg-blue-600 text-white text-sm rounded-r-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed";
        sendButton.onclick = handleSendMessage;

        inputAreaDiv.appendChild(inputField);
        inputAreaDiv.appendChild(sendButton);
        mainDiv.appendChild(inputAreaDiv);

        containerElement.appendChild(mainDiv);

        // Initial UI update after elements are created
        updateUI();
    }

    // Call render function to build the UI
    renderChatbotUI();
}

// Global variable to hold the single chatbot container instance
let chatbotContainerInstance = null;
let isChatbotOpen = false;

/**
 * Main application logic for the floating chatbot button and conditional display.
 * This function handles the visibility of the chatbot window.
 */
function initializeChatbotApp() {
    // Create the floating chatbot button if it doesn't exist
    let toggleButton = document.getElementById('chatbot-toggle-button');
    if (!toggleButton) {
        toggleButton = document.createElement('button');
        toggleButton.id = 'chatbot-toggle-button'; // Assign an ID for easier lookup
        toggleButton.className = "fixed bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg cursor-pointer z-50 text-xl hover:bg-blue-700 transition-colors duration-300 transform hover:scale-110 active:scale-95";
        toggleButton.title = "Open Chat Assistant";
        toggleButton.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/>
            </svg>
        `;

        const rootElement = document.getElementById('react-chatbot-root');
        if (rootElement) {
            rootElement.parentNode.insertBefore(toggleButton, rootElement);
        } else {
            document.body.appendChild(toggleButton);
        }
    }


    // Function to toggle chatbot visibility
    const toggleChatbot = () => {
        isChatbotOpen = !isChatbotOpen;
        renderChatbotWindow();
    };

    toggleButton.onclick = toggleChatbot;

    // Function to render/remove the chatbot window
    function renderChatbotWindow() {
        if (isChatbotOpen) {
            // Create chatbot container only once
            if (!chatbotContainerInstance) {
                chatbotContainerInstance = document.createElement('div');
                chatbotContainerInstance.className = "fixed bottom-24 right-6 w-80 h-[450px] sm:w-96 sm:h-[500px] bg-white rounded-xl shadow-2xl flex flex-col z-50 animate-fade-in-up";
                document.body.appendChild(chatbotContainerInstance); // Append to body only once
            }

            // Create and render the ChatbotView inside the container
            // This will re-render the chatbot UI components inside the *existing* container
            createChatbotView(chatbotContainerInstance, () => {
                isChatbotOpen = false; // Update state
                renderChatbotWindow(); // Re-render to hide the window
            });
            chatbotContainerInstance.style.display = 'flex'; // Ensure it's visible
        } else {
            // Hide the chatbot container
            if (chatbotContainerInstance) {
                chatbotContainerInstance.style.display = 'none';
            }
        }
    }
}

// Initialize the entire chatbot application when the DOM is ready
document.addEventListener('DOMContentLoaded', initializeChatbotApp);